/*
  # Add store code authentication

  1. Changes
    - Add store_code column to stores table
    - Add functions for store authentication
    - Add necessary indexes and constraints

  2. Security
    - All functions are security definer
    - Proper search path set
    - Execute permissions granted to authenticated users
*/

-- Add store_code column to stores table
ALTER TABLE stores
ADD COLUMN store_code text;

-- Add unique constraint to store_code
ALTER TABLE stores
ADD CONSTRAINT stores_store_code_unique UNIQUE (store_code);

-- Create index for faster lookups
CREATE INDEX idx_stores_store_code ON stores(store_code);

-- Function to verify store credentials
CREATE OR REPLACE FUNCTION verify_store_credentials(
  check_phone text,
  check_code text
)
RETURNS TABLE (
  id uuid,
  name text,
  phone text,
  store_code text
) 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    s.id,
    s.name,
    s.phone,
    s.store_code
  FROM stores s
  WHERE s.phone = check_phone
  AND s.store_code = check_code;
END;
$$;

-- Function to update store's user_id
CREATE OR REPLACE FUNCTION update_store_user_id(
  store_phone text,
  new_user_id uuid
)
RETURNS void
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE stores
  SET store_user_id = new_user_id
  WHERE phone = store_phone;
END;
$$;

-- Grant execute permissions to authenticated users
GRANT EXECUTE ON FUNCTION verify_store_credentials(text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION update_store_user_id(text, uuid) TO authenticated;