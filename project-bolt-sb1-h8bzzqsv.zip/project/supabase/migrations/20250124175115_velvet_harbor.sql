/*
  # Admin Users and Permissions Update

  1. New Tables
    - `admin_users`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on admin_users table
    - Add policies for admin access
    - Update driver and store policies to use admin_users table

  3. Changes
    - Simplify permission checks using admin_users table
    - Remove complex JWT checks
    - Add initial admin user based on metadata
*/

-- Create admin_users table
CREATE TABLE IF NOT EXISTS admin_users (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES auth.users NOT NULL,
    created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- Admin users policies
CREATE POLICY "Allow read access to authenticated users"
    ON admin_users FOR SELECT
    TO authenticated
    USING (true);

-- Reset existing policies for drivers
DROP POLICY IF EXISTS "Anyone can view drivers" ON drivers;
DROP POLICY IF EXISTS "Admin can insert drivers" ON drivers;
DROP POLICY IF EXISTS "Admin can update drivers" ON drivers;
DROP POLICY IF EXISTS "Admin can delete drivers" ON drivers;

-- New policies for drivers using admin_users table
CREATE POLICY "Anyone can view drivers"
    ON drivers FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "Admin can manage drivers"
    ON drivers FOR ALL
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM admin_users
            WHERE admin_users.user_id = auth.uid()
        )
    );

-- Reset and update store policies
DROP POLICY IF EXISTS "Anyone can view stores" ON stores;
DROP POLICY IF EXISTS "Admins can manage stores" ON stores;

CREATE POLICY "Anyone can view stores"
    ON stores FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "Admin can manage stores"
    ON stores FOR ALL
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM admin_users
            WHERE admin_users.user_id = auth.uid()
        )
    );

-- Function to automatically add admin users based on metadata
CREATE OR REPLACE FUNCTION public.handle_new_user() 
RETURNS trigger AS $$
BEGIN
    IF NEW.raw_user_meta_data->>'role' = 'admin' THEN
        INSERT INTO public.admin_users (user_id)
        VALUES (NEW.id)
        ON CONFLICT (user_id) DO NOTHING;
    END IF;
    RETURN NEW;
END;
$$ language plpgsql security definer;

-- Trigger to automatically add admin users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();