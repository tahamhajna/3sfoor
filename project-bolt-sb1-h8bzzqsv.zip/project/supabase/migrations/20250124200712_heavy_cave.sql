/*
  # Fix admin check in orders policies

  1. Changes
    - Update orders policies to use the correct admin check with SPLIT_PART
    - Ensure consistent admin check across all policies
*/

-- Drop existing admin policy for orders
DROP POLICY IF EXISTS "Admin manage orders" ON orders;

-- Create new policy with fixed admin check
CREATE POLICY "Admin manage orders"
  ON orders FOR ALL
  TO authenticated
  USING (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  )
  WITH CHECK (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  );