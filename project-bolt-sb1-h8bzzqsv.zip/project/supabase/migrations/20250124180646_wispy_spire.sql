-- Update drivers policies with explicit table references
DROP POLICY IF EXISTS "Drivers manage themselves" ON drivers;
CREATE POLICY "Drivers manage themselves"
  ON drivers FOR UPDATE
  TO authenticated
  USING (drivers.user_id = auth.uid())
  WITH CHECK (drivers.user_id = auth.uid());

-- Update stores policies with explicit table references
DROP POLICY IF EXISTS "Stores manage themselves" ON stores;
CREATE POLICY "Stores manage themselves"
  ON stores FOR UPDATE
  TO authenticated
  USING (stores.user_id = auth.uid())
  WITH CHECK (stores.user_id = auth.uid());

-- Update orders policies with explicit table references
DROP POLICY IF EXISTS "Stores manage their orders" ON orders;
CREATE POLICY "Stores manage their orders"
  ON orders FOR ALL
  TO authenticated
  USING (
    store_id IN (
      SELECT stores.id FROM stores WHERE stores.user_id = auth.uid()
    )
  )
  WITH CHECK (
    store_id IN (
      SELECT stores.id FROM stores WHERE stores.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "Drivers manage assigned orders" ON orders;
CREATE POLICY "Drivers manage assigned orders"
  ON orders FOR UPDATE
  TO authenticated
  USING (
    driver_id IN (
      SELECT drivers.id FROM drivers WHERE drivers.user_id = auth.uid()
    )
  )
  WITH CHECK (
    driver_id IN (
      SELECT drivers.id FROM drivers WHERE drivers.user_id = auth.uid()
    )
  );