/*
  # Add incremental IDs to tables

  1. Changes
    - Add incremental ID columns to orders, drivers, and stores tables
    - Create sequences for each table
    - Migrate existing data to use new incremental IDs
    - Add indexes for better performance

  2. Security
    - No changes to RLS policies needed
    - Existing security remains intact

  3. Notes
    - Incremental IDs are added as a separate column to maintain UUID compatibility
    - Original UUIDs are kept for external references
*/

-- Create sequences for incremental IDs
CREATE SEQUENCE IF NOT EXISTS orders_number_seq;
CREATE SEQUENCE IF NOT EXISTS drivers_number_seq;
CREATE SEQUENCE IF NOT EXISTS stores_number_seq;

-- Add incremental ID columns
ALTER TABLE orders ADD COLUMN IF NOT EXISTS order_number bigint UNIQUE;
ALTER TABLE drivers ADD COLUMN IF NOT EXISTS driver_number bigint UNIQUE;
ALTER TABLE stores ADD COLUMN IF NOT EXISTS store_number bigint UNIQUE;

-- Create indexes for the new columns
CREATE INDEX IF NOT EXISTS idx_orders_number ON orders(order_number);
CREATE INDEX IF NOT EXISTS idx_drivers_number ON drivers(driver_number);
CREATE INDEX IF NOT EXISTS idx_stores_number ON stores(store_number);

-- Migrate existing data
DO $$ 
BEGIN
  -- Update orders
  UPDATE orders 
  SET order_number = nextval('orders_number_seq')
  WHERE order_number IS NULL;

  -- Update drivers
  UPDATE drivers 
  SET driver_number = nextval('drivers_number_seq')
  WHERE driver_number IS NULL;

  -- Update stores
  UPDATE stores 
  SET store_number = nextval('stores_number_seq')
  WHERE store_number IS NULL;
END $$;

-- Set default values for new records
ALTER TABLE orders ALTER COLUMN order_number SET DEFAULT nextval('orders_number_seq');
ALTER TABLE drivers ALTER COLUMN driver_number SET DEFAULT nextval('drivers_number_seq');
ALTER TABLE stores ALTER COLUMN store_number SET DEFAULT nextval('stores_number_seq');

-- Add NOT NULL constraint after migration
ALTER TABLE orders ALTER COLUMN order_number SET NOT NULL;
ALTER TABLE drivers ALTER COLUMN driver_number SET NOT NULL;
ALTER TABLE stores ALTER COLUMN store_number SET NOT NULL;