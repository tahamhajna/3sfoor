/*
  # Add order acceptance function
  
  1. Changes
    - Creates a simpler, more efficient order acceptance function
    - Uses direct update with returning instead of CTE
    - Implements proper error handling
  
  2. Security
    - Function runs with SECURITY DEFINER
    - Explicit search_path set for security
*/

-- Drop existing function if it exists
DROP FUNCTION IF EXISTS accept_order(bigint, bigint);

-- Create simplified function to handle order acceptance
CREATE OR REPLACE FUNCTION accept_order(
  p_order_number bigint,
  p_driver_number bigint
)
RETURNS SETOF orders
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_result orders;
BEGIN
  -- Attempt to update the order
  UPDATE orders
  SET 
    driver_number = p_driver_number,
    status = 'waiting_for_delivery',
    updated_at = now()
  WHERE order_number = p_order_number
    AND status = 'pending'
    AND driver_number IS NULL
  RETURNING *
  INTO v_result;

  -- Check if update was successful
  IF v_result IS NULL THEN
    RAISE EXCEPTION 'Order not found or no longer available';
  END IF;

  RETURN NEXT v_result;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION accept_order(bigint, bigint) TO authenticated;