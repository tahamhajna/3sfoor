/*
  # Update admin user constraints and policies

  1. Changes
    - Add unique constraint to admin_users table
    - Update admin check function
    - Update driver policies with proper checks

  2. Security
    - Maintain RLS on all tables
    - Ensure proper admin role checks
    - Clean policy management
*/

-- Add unique constraint to admin_users if not exists
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'admin_users_user_id_key'
  ) THEN
    ALTER TABLE admin_users ADD CONSTRAINT admin_users_user_id_key UNIQUE (user_id);
  END IF;
END $$;

-- Function to check if user is admin
CREATE OR REPLACE FUNCTION public.is_admin(user_id uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM admin_users WHERE admin_users.user_id = user_id
  ) OR EXISTS (
    SELECT 1 FROM auth.users 
    WHERE auth.users.id = user_id 
    AND (
      auth.users.raw_user_meta_data->>'role' = 'admin' OR
      auth.users.raw_app_meta_data->>'role' = 'admin'
    )
  );
END;
$$ language plpgsql security definer;

-- Drop existing policies first
DROP POLICY IF EXISTS "Public read access" ON drivers;
DROP POLICY IF EXISTS "Admin full access" ON drivers;
DROP POLICY IF EXISTS "Anyone can view drivers" ON drivers;
DROP POLICY IF EXISTS "Admin can manage drivers" ON drivers;

-- Create new policies
CREATE POLICY "Drivers public read access"
  ON drivers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Drivers admin management"
  ON drivers FOR ALL
  TO authenticated
  USING (is_admin(auth.uid()))
  WITH CHECK (is_admin(auth.uid()));

-- Update handle_new_user function
CREATE OR REPLACE FUNCTION public.handle_new_user() 
RETURNS trigger AS $$
BEGIN
  IF (
    NEW.raw_user_meta_data->>'role' = 'admin' OR
    NEW.raw_app_meta_data->>'role' = 'admin'
  ) THEN
    INSERT INTO public.admin_users (user_id)
    VALUES (NEW.id)
    ON CONFLICT (user_id) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$ language plpgsql security definer;