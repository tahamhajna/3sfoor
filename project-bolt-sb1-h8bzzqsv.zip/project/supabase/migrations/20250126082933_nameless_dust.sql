/*
  # Add delivery price to orders

  1. Changes
    - Add delivery_price column to orders table with default value of 15
    - Add check constraint to ensure price is non-negative
*/

-- Add delivery_price column to orders table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'orders' AND column_name = 'delivery_price'
  ) THEN
    ALTER TABLE orders ADD COLUMN delivery_price numeric(10,2) NOT NULL DEFAULT 15.00;
    
    -- Add check constraint to ensure price is non-negative
    ALTER TABLE orders ADD CONSTRAINT orders_delivery_price_check CHECK (delivery_price >= 0);
  END IF;
END $$;