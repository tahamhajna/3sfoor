/*
  # Update Primary Keys to Number Columns

  1. Changes
    - Make order_number the primary key for orders table
    - Make driver_number the primary key for drivers table
    - Make store_number the primary key for stores table
    - Drop old UUID-based primary keys
  
  2. Process
    - Temporarily disable RLS
    - Drop existing foreign key constraints
    - Drop old primary key constraints
    - Add new primary key constraints
    - Re-add foreign key constraints
    - Re-enable RLS
*/

-- Temporarily disable RLS
ALTER TABLE orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE drivers DISABLE ROW LEVEL SECURITY;
ALTER TABLE stores DISABLE ROW LEVEL SECURITY;

-- Drop existing foreign key constraints
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_store_number_fkey;
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_driver_number_fkey;

-- Drop old primary key constraints
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_pkey;
ALTER TABLE drivers DROP CONSTRAINT IF EXISTS drivers_pkey;
ALTER TABLE stores DROP CONSTRAINT IF EXISTS stores_pkey;

-- Add new primary key constraints
ALTER TABLE orders ADD PRIMARY KEY (order_number);
ALTER TABLE drivers ADD PRIMARY KEY (driver_number);
ALTER TABLE stores ADD PRIMARY KEY (store_number);

-- Re-add foreign key constraints
ALTER TABLE orders 
  ADD CONSTRAINT orders_store_number_fkey 
  FOREIGN KEY (store_number) 
  REFERENCES stores(store_number);

ALTER TABLE orders 
  ADD CONSTRAINT orders_driver_number_fkey 
  FOREIGN KEY (driver_number) 
  REFERENCES drivers(driver_number);

-- Re-enable RLS
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE drivers ENABLE ROW LEVEL SECURITY;
ALTER TABLE stores ENABLE ROW LEVEL SECURITY;