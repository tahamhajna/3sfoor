/*
  # Add driver code column

  1. Changes
    - Add driver_code column to drivers table
    - Make driver_code unique and required
    - Add index for faster lookups
*/

-- Add driver_code column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'drivers' AND column_name = 'driver_code'
  ) THEN
    ALTER TABLE drivers ADD COLUMN driver_code text NOT NULL DEFAULT gen_random_uuid()::text;
    ALTER TABLE drivers ALTER COLUMN driver_code DROP DEFAULT;
    ALTER TABLE drivers ADD CONSTRAINT drivers_driver_code_unique UNIQUE (driver_code);
    CREATE INDEX idx_drivers_driver_code ON drivers(driver_code);
  END IF;
END $$;