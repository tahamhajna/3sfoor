/*
  # Update Database Functions for Number-Based IDs
  
  1. Changes
    - Update verify_driver_credentials to use driver_number
    - Update verify_store_credentials to use store_number
    - Update driver and store user_id update functions
    
  2. Security
    - Maintain existing security definer settings
    - Keep all functions accessible to authenticated users
*/

-- Drop existing functions
DROP FUNCTION IF EXISTS verify_driver_credentials(text, text);
DROP FUNCTION IF EXISTS verify_store_credentials(text, text);
DROP FUNCTION IF EXISTS update_driver_user_id(text, uuid);
DROP FUNCTION IF EXISTS update_store_user_id(text, uuid);

-- Function to verify driver credentials
CREATE OR REPLACE FUNCTION verify_driver_credentials(
  check_phone text,
  check_code text
)
RETURNS TABLE (
  driver_number bigint,
  name text,
  phone text,
  driver_code text
) 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    d.driver_number,
    d.name,
    d.phone,
    d.driver_code
  FROM drivers d
  WHERE d.phone = check_phone
  AND d.driver_code = check_code;
END;
$$;

-- Function to verify store credentials
CREATE OR REPLACE FUNCTION verify_store_credentials(
  check_phone text,
  check_code text
)
RETURNS TABLE (
  store_number bigint,
  name text,
  phone text,
  store_code text
) 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    s.store_number,
    s.name,
    s.phone,
    s.store_code
  FROM stores s
  WHERE s.phone = check_phone
  AND s.store_code = check_code;
END;
$$;

-- Function to update driver's user_id
CREATE OR REPLACE FUNCTION update_driver_user_id(
  driver_phone text,
  new_user_id uuid
)
RETURNS void
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE drivers
  SET driver_user_id = new_user_id
  WHERE phone = driver_phone;
END;
$$;

-- Function to update store's user_id
CREATE OR REPLACE FUNCTION update_store_user_id(
  store_phone text,
  new_user_id uuid
)
RETURNS void
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE stores
  SET store_user_id = new_user_id
  WHERE phone = store_phone;
END;
$$;

-- Grant execute permissions to authenticated users
GRANT EXECUTE ON FUNCTION verify_driver_credentials(text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION verify_store_credentials(text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION update_driver_user_id(text, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION update_store_user_id(text, uuid) TO authenticated;