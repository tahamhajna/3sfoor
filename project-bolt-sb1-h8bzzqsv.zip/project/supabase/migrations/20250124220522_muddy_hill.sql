/*
  # Update primary keys to use incremental numbers
  
  1. Changes
    - Drop policies first to remove dependencies
    - Add new columns for foreign key references
    - Update foreign key references
    - Drop old columns
    - Recreate RLS policies
  
  2. Security
    - Maintain existing RLS policies with updated column references
    - Ensure data integrity during migration
*/

-- First drop all policies that depend on the UUID columns
DROP POLICY IF EXISTS "Stores manage their orders" ON orders;
DROP POLICY IF EXISTS "Drivers manage assigned orders" ON orders;
DROP POLICY IF EXISTS "Admin manage orders" ON orders;
DROP POLICY IF EXISTS "Public read access for orders" ON orders;

-- Temporarily disable RLS
ALTER TABLE orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE drivers DISABLE ROW LEVEL SECURITY;
ALTER TABLE stores DISABLE ROW LEVEL SECURITY;

-- Drop existing foreign key constraints
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_store_id_fkey;
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_driver_id_fkey;

-- Add new columns for foreign keys
ALTER TABLE orders 
  ADD COLUMN store_number_fk bigint,
  ADD COLUMN driver_number_fk bigint;

-- Update the new foreign key columns with values from the number columns
UPDATE orders o
SET 
  store_number_fk = s.store_number,
  driver_number_fk = d.driver_number
FROM stores s, drivers d
WHERE o.store_id = s.id
  AND (o.driver_id = d.id OR o.driver_id IS NULL);

-- Drop old columns
ALTER TABLE orders DROP COLUMN store_id;
ALTER TABLE orders DROP COLUMN driver_id;

-- Rename new columns to final names
ALTER TABLE orders RENAME COLUMN store_number_fk TO store_number;
ALTER TABLE orders RENAME COLUMN driver_number_fk TO driver_number;

-- Add foreign key constraints
ALTER TABLE orders 
  ADD CONSTRAINT orders_store_number_fkey 
  FOREIGN KEY (store_number) 
  REFERENCES stores(store_number);

ALTER TABLE orders 
  ADD CONSTRAINT orders_driver_number_fkey 
  FOREIGN KEY (driver_number) 
  REFERENCES drivers(driver_number);

-- Re-enable RLS
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE drivers ENABLE ROW LEVEL SECURITY;
ALTER TABLE stores ENABLE ROW LEVEL SECURITY;

-- Recreate RLS policies with new column references
CREATE POLICY "Public read access for orders"
  ON orders FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admin manage orders"
  ON orders FOR ALL
  TO authenticated
  USING (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  )
  WITH CHECK (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  );

CREATE POLICY "Stores manage their orders"
  ON orders FOR ALL
  TO authenticated
  USING (
    store_number IN (
      SELECT stores.store_number FROM stores WHERE stores.store_user_id = auth.uid()
    )
  )
  WITH CHECK (
    store_number IN (
      SELECT stores.store_number FROM stores WHERE stores.store_user_id = auth.uid()
    )
  );

CREATE POLICY "Drivers manage assigned orders"
  ON orders FOR UPDATE
  TO authenticated
  USING (
    driver_number IN (
      SELECT drivers.driver_number FROM drivers WHERE drivers.driver_user_id = auth.uid()
    )
  )
  WITH CHECK (
    driver_number IN (
      SELECT drivers.driver_number FROM drivers WHERE drivers.driver_user_id = auth.uid()
    )
  );