/*
  # Fix database policies

  1. Changes
    - Update RLS policies to allow proper access to tables
    - Add policies for authenticated users to view data
    - Fix permission denied errors

  2. Security
    - Maintain row-level security
    - Add proper policies for data access
*/

-- Update drivers policies
DROP POLICY IF EXISTS "Drivers can read own data" ON drivers;
DROP POLICY IF EXISTS "Admin can manage drivers" ON drivers;

CREATE POLICY "Anyone can view drivers"
  ON drivers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage drivers"
  ON drivers
  FOR ALL
  TO authenticated
  USING (
    auth.jwt() ->> 'role' = 'admin'
  );

-- Update stores policies
DROP POLICY IF EXISTS "Stores can read own data" ON stores;
DROP POLICY IF EXISTS "Admin can manage stores" ON stores;

CREATE POLICY "Anyone can view stores"
  ON stores FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage stores"
  ON stores
  FOR ALL
  TO authenticated
  USING (
    auth.jwt() ->> 'role' = 'admin'
  );

-- Update orders policies
DROP POLICY IF EXISTS "Stores can manage own orders" ON orders;
DROP POLICY IF EXISTS "Drivers can see and update assigned orders" ON orders;
DROP POLICY IF EXISTS "Admin can manage all orders" ON orders;

CREATE POLICY "Anyone can view orders"
  ON orders FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage orders"
  ON orders
  FOR ALL
  TO authenticated
  USING (
    auth.jwt() ->> 'role' = 'admin'
  );

CREATE POLICY "Drivers can update their assigned orders"
  ON orders
  FOR UPDATE
  TO authenticated
  USING (
    driver_id IN (
      SELECT id FROM drivers
      WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Stores can create and manage their orders"
  ON orders
  FOR ALL
  TO authenticated
  USING (
    store_id IN (
      SELECT id FROM stores
      WHERE user_id = auth.uid()
    )
  );