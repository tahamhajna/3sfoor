/*
  # Remove status constraint from orders table
  
  1. Changes
    - Removes the status check constraint from orders table
  
  2. Notes
    - Uses ALTER TABLE to directly remove the constraint
    - No DO block to avoid connection timeout issues
*/

-- Remove the status check constraint
ALTER TABLE orders DROP CONSTRAINT IF EXISTS orders_status_check;