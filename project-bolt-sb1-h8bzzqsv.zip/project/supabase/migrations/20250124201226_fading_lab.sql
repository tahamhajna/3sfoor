-- Drop existing policies for drivers
DROP POLICY IF EXISTS "Public read access for drivers" ON drivers;
DROP POLICY IF EXISTS "Admin manage drivers" ON drivers;
DROP POLICY IF EXISTS "Drivers manage themselves" ON drivers;

-- Create new policies for drivers
CREATE POLICY "Anyone can view drivers"
  ON drivers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admin can manage drivers"
  ON drivers FOR ALL
  TO authenticated
  USING (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  )
  WITH CHECK (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  );

CREATE POLICY "Drivers can update their own status"
  ON drivers FOR UPDATE
  TO authenticated
  USING (
    driver_user_id = auth.uid()
  )
  WITH CHECK (
    driver_user_id = auth.uid()
  );

-- Add unique constraint to phone number
ALTER TABLE drivers
ADD CONSTRAINT drivers_phone_unique UNIQUE (phone);