-- Add blocked column to stores table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'stores' AND column_name = 'blocked'
  ) THEN
    ALTER TABLE stores ADD COLUMN blocked boolean NOT NULL DEFAULT false;
  END IF;
END $$;

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Admin manage stores" ON stores;
DROP POLICY IF EXISTS "Public read access for stores" ON stores;
DROP POLICY IF EXISTS "Stores manage themselves" ON stores;

-- Recreate policies with blocked column handling
CREATE POLICY "Anyone can view stores"
  ON stores FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admin can manage stores"
  ON stores FOR ALL
  TO authenticated
  USING (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  )
  WITH CHECK (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  );

CREATE POLICY "Stores can update themselves"
  ON stores FOR UPDATE
  TO authenticated
  USING (
    store_user_id = auth.uid()
  )
  WITH CHECK (
    store_user_id = auth.uid()
  );

-- Update orders policies to prevent blocked stores from creating orders
DROP POLICY IF EXISTS "Stores manage their orders" ON orders;

CREATE POLICY "Stores manage their orders"
  ON orders FOR ALL
  TO authenticated
  USING (
    store_number IN (
      SELECT stores.store_number 
      FROM stores 
      WHERE stores.store_user_id = auth.uid()
      AND NOT stores.blocked
    )
  )
  WITH CHECK (
    store_number IN (
      SELECT stores.store_number 
      FROM stores 
      WHERE stores.store_user_id = auth.uid()
      AND NOT stores.blocked
    )
  );