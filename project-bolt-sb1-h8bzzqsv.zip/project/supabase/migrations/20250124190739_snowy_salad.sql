/*
  # Fix admin check in RLS policies

  1. Changes
    - Update admin check to use SPLIT_PART to extract username from email
    - Fix drivers policy to properly check admin status
    - Add explicit WITH CHECK clauses
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Admin manage drivers" ON drivers;

-- Create new policy with fixed admin check
CREATE POLICY "Admin manage drivers"
  ON drivers FOR ALL
  TO authenticated
  USING (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  )
  WITH CHECK (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  );