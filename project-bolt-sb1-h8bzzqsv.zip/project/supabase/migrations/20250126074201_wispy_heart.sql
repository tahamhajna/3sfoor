/*
  # Add blocked column to drivers table

  1. Changes
    - Add `blocked` boolean column to drivers table with default value false
    - Update RLS policies to handle blocked status

  2. Security
    - Only admins can update any driver data
    - Drivers can only update their own is_active status when not blocked
    - Everyone can view driver data
*/

-- Add blocked column to drivers table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'drivers' AND column_name = 'blocked'
  ) THEN
    ALTER TABLE drivers ADD COLUMN blocked boolean NOT NULL DEFAULT false;
  END IF;
END $$;

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Admin can manage drivers" ON drivers;
DROP POLICY IF EXISTS "Anyone can view drivers" ON drivers;
DROP POLICY IF EXISTS "Drivers can update their own status" ON drivers;

-- Recreate policies with blocked column handling
CREATE POLICY "Anyone can view drivers"
  ON drivers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admin can manage drivers"
  ON drivers FOR ALL
  TO authenticated
  USING (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  )
  WITH CHECK (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  );

-- Drivers can only update their own is_active status
CREATE POLICY "Drivers can update their own status"
  ON drivers FOR UPDATE
  TO authenticated
  USING (
    driver_user_id = auth.uid()
  )
  WITH CHECK (
    driver_user_id = auth.uid()
  );