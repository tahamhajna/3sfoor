-- Drop and recreate verify_password function with correct parameter names
DROP FUNCTION IF EXISTS verify_password(text, text);

CREATE OR REPLACE FUNCTION verify_password(check_username text, check_password text)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM admin_users
    WHERE admin_users.username = check_username
    AND admin_users.password_hash = crypt(check_password, admin_users.password_hash)
  );
END;
$$ language plpgsql security definer;