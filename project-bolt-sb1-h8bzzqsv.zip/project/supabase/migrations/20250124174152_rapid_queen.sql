/*
  # Final fix for RLS policies

  1. Changes
    - Simplify RLS policies for admin access
    - Add explicit policies for each operation type
    - Ensure proper role checking
    - Fix permission issues for admin operations

  2. Security
    - Maintain strict access control
    - Ensure proper admin privileges
*/

-- Reset existing policies
DROP POLICY IF EXISTS "Anyone can view drivers" ON drivers;
DROP POLICY IF EXISTS "Admins can manage drivers" ON drivers;

-- Create more specific policies for drivers
CREATE POLICY "Allow read access to authenticated users"
  ON drivers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow admin insert"
  ON drivers FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.jwt() ->> 'role' = 'admin'
  );

CREATE POLICY "Allow admin update"
  ON drivers FOR UPDATE
  TO authenticated
  USING (
    auth.jwt() ->> 'role' = 'admin'
  )
  WITH CHECK (
    auth.jwt() ->> 'role' = 'admin'
  );

CREATE POLICY "Allow admin delete"
  ON drivers FOR DELETE
  TO authenticated
  USING (
    auth.jwt() ->> 'role' = 'admin'
  );