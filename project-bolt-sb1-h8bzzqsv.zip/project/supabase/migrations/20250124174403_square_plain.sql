/*
  # Final RLS policy fix

  1. Changes
    - Fix role checking using correct Supabase method
    - Add proper policies for all operations
    - Ensure admin access works correctly

  2. Security
    - Maintain strict access control
    - Use proper role verification
*/

-- Reset existing policies
DROP POLICY IF EXISTS "Allow read access to authenticated users" ON drivers;
DROP POLICY IF EXISTS "Allow admin insert" ON drivers;
DROP POLICY IF EXISTS "Allow admin update" ON drivers;
DROP POLICY IF EXISTS "Allow admin delete" ON drivers;

-- Create new policies with correct role checking
CREATE POLICY "Anyone can view drivers"
  ON drivers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admin can insert drivers"
  ON drivers FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1
      FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.raw_user_meta_data->>'role' = 'admin'
    )
  );

CREATE POLICY "Admin can update drivers"
  ON drivers FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.raw_user_meta_data->>'role' = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1
      FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.raw_user_meta_data->>'role' = 'admin'
    )
  );

CREATE POLICY "Admin can delete drivers"
  ON drivers FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND auth.users.raw_user_meta_data->>'role' = 'admin'
    )
  );