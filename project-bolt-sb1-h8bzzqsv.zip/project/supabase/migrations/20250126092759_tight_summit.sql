-- Drop existing function if it exists
DROP FUNCTION IF EXISTS accept_order(bigint, bigint);

-- Create function to handle order acceptance with qualified column names
CREATE OR REPLACE FUNCTION accept_order(
  p_order_number bigint,
  p_driver_number bigint
)
RETURNS TABLE (
  order_number bigint,
  store_number bigint,
  driver_number bigint,
  pickup_address text,
  delivery_address text,
  description text,
  delivery_price numeric,
  status text,
  created_at timestamptz,
  updated_at timestamptz
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_driver_active boolean;
  v_driver_blocked boolean;
BEGIN
  -- Check driver status first with qualified column reference
  SELECT d.is_active, d.blocked INTO v_driver_active, v_driver_blocked
  FROM drivers d
  WHERE d.driver_number = p_driver_number;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Driver not found';
  END IF;

  IF NOT v_driver_active THEN
    RAISE EXCEPTION 'Driver must be active to accept orders';
  END IF;

  IF v_driver_blocked THEN
    RAISE EXCEPTION 'Blocked drivers cannot accept orders';
  END IF;

  -- Update the order with qualified column references
  RETURN QUERY
  WITH updated AS (
    UPDATE orders o
    SET 
      driver_number = p_driver_number,
      status = 'waiting_for_delivery',
      updated_at = now()
    WHERE o.order_number = p_order_number
      AND o.status = 'pending'
      AND o.driver_number IS NULL
    RETURNING *
  )
  SELECT * FROM updated;

  -- Check if update was successful
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Order not found or no longer available';
  END IF;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION accept_order(bigint, bigint) TO authenticated;