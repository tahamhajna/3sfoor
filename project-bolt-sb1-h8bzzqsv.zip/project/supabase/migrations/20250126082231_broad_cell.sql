/*
  # Add description field to orders

  1. Changes
    - Add description column to orders table
    - Make it nullable since not all orders need a description
    - Add index for faster text search

  2. Notes
    - No data migration needed as new column is nullable
    - Existing orders will have NULL description
*/

-- Add description column to orders table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'orders' AND column_name = 'description'
  ) THEN
    ALTER TABLE orders ADD COLUMN description text;
    
    -- Create an index for text search on description
    CREATE INDEX idx_orders_description ON orders USING gin(to_tsvector('english', coalesce(description, '')));
  END IF;
END $$;