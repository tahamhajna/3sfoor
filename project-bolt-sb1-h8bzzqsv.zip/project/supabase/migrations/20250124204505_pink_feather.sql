/*
  # Add driver authentication functions
  
  1. New Functions
    - get_all_drivers() - Securely fetch all drivers for debugging
    - verify_driver_credentials() - Verify driver login credentials
    - update_driver_user_id() - Update driver's user ID after authentication
  
  2. Security
    - All functions are SECURITY DEFINER to bypass RLS
    - Strict input validation
    - Safe error handling
*/

-- Function to get all drivers (for debugging)
CREATE OR REPLACE FUNCTION get_all_drivers()
RETURNS TABLE (
  id uuid,
  name text,
  phone text,
  driver_code text,
  is_active boolean
) 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    d.id,
    d.name,
    d.phone,
    d.driver_code,
    d.is_active
  FROM drivers d;
END;
$$;

-- Function to verify driver credentials
CREATE OR REPLACE FUNCTION verify_driver_credentials(
  check_phone text,
  check_code text
)
RETURNS TABLE (
  id uuid,
  name text,
  phone text,
  driver_code text
) 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    d.id,
    d.name,
    d.phone,
    d.driver_code
  FROM drivers d
  WHERE d.phone = check_phone
  AND d.driver_code = check_code;
END;
$$;

-- Function to update driver's user_id
CREATE OR REPLACE FUNCTION update_driver_user_id(
  driver_phone text,
  new_user_id uuid
)
RETURNS void
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE drivers
  SET driver_user_id = new_user_id
  WHERE phone = driver_phone;
END;
$$;

-- Grant execute permissions to authenticated users
GRANT EXECUTE ON FUNCTION get_all_drivers() TO authenticated;
GRANT EXECUTE ON FUNCTION verify_driver_credentials(text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION update_driver_user_id(text, uuid) TO authenticated;