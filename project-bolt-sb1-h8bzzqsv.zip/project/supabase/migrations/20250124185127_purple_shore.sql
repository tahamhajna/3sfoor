-- Enable pgcrypto extension if not enabled
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Drop existing trigger and function
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS handle_new_user();
DROP FUNCTION IF EXISTS is_admin();
DROP FUNCTION IF EXISTS check_admin_status();

-- Drop and recreate admin_users table
DROP TABLE IF EXISTS admin_users CASCADE;
CREATE TABLE admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Function to hash password
CREATE OR REPLACE FUNCTION hash_password(password text)
RETURNS text AS $$
BEGIN
  RETURN crypt(password, gen_salt('bf'));
END;
$$ language plpgsql security definer;

-- Function to verify password
CREATE OR REPLACE FUNCTION verify_password(username text, password text)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM admin_users
    WHERE admin_users.username = verify_password.username
    AND admin_users.password_hash = crypt(verify_password.password, admin_users.password_hash)
  );
END;
$$ language plpgsql security definer;

-- Function to check if user is admin
CREATE OR REPLACE FUNCTION check_admin_status(check_username text)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM admin_users WHERE admin_users.username = check_username
  );
END;
$$ language plpgsql security definer;

-- Enable RLS
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- Admin users policies
CREATE POLICY "Public read access for admin_users"
  ON admin_users FOR SELECT
  TO authenticated
  USING (true);

-- Insert initial admin user (username: admin, password: admin123)
INSERT INTO admin_users (username, password_hash)
VALUES ('admin', crypt('admin123', gen_salt('bf')))
ON CONFLICT (username) DO NOTHING;