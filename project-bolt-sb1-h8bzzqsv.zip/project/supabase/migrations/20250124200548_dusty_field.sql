/*
  # Fix admin check in RLS policies for stores

  1. Changes
    - Update stores policy to properly check admin status using SPLIT_PART
    - Add explicit WITH CHECK clauses
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Admin manage stores" ON stores;

-- Create new policy with fixed admin check
CREATE POLICY "Admin manage stores"
  ON stores FOR ALL
  TO authenticated
  USING (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  )
  WITH CHECK (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  );