/*
  # Remove UUID columns and update references

  1. Changes
    - Drop all policies that depend on UUID columns
    - Drop foreign key constraints
    - Drop UUID columns from all tables
    - Update references to use number columns
    - Recreate policies with new column references

  2. Security
    - Temporarily disable RLS during migration
    - Re-enable RLS after changes
    - Recreate all policies with updated column references
*/

-- First drop all policies
DROP POLICY IF EXISTS "Stores manage their orders" ON orders;
DROP POLICY IF EXISTS "Drivers manage assigned orders" ON orders;
DROP POLICY IF EXISTS "Admin manage orders" ON orders;
DROP POLICY IF EXISTS "Public read access for orders" ON orders;
DROP POLICY IF EXISTS "Anyone can view drivers" ON drivers;
DROP POLICY IF EXISTS "Admin can manage drivers" ON drivers;
DROP POLICY IF EXISTS "Drivers can update their own status" ON drivers;
DROP POLICY IF EXISTS "Public read access for stores" ON stores;
DROP POLICY IF EXISTS "Admin manage stores" ON stores;
DROP POLICY IF EXISTS "Stores manage themselves" ON stores;

-- Temporarily disable RLS
ALTER TABLE orders DISABLE ROW LEVEL SECURITY;
ALTER TABLE drivers DISABLE ROW LEVEL SECURITY;
ALTER TABLE stores DISABLE ROW LEVEL SECURITY;

-- Drop UUID columns from tables
ALTER TABLE orders DROP COLUMN IF EXISTS id;
ALTER TABLE drivers DROP COLUMN IF EXISTS id;
ALTER TABLE stores DROP COLUMN IF EXISTS id;

-- Re-enable RLS
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE drivers ENABLE ROW LEVEL SECURITY;
ALTER TABLE stores ENABLE ROW LEVEL SECURITY;

-- Recreate policies for drivers
CREATE POLICY "Anyone can view drivers"
  ON drivers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admin can manage drivers"
  ON drivers FOR ALL
  TO authenticated
  USING (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  )
  WITH CHECK (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  );

CREATE POLICY "Drivers can update their own status"
  ON drivers FOR UPDATE
  TO authenticated
  USING (
    driver_user_id = auth.uid()
  )
  WITH CHECK (
    driver_user_id = auth.uid()
  );

-- Recreate policies for stores
CREATE POLICY "Public read access for stores"
  ON stores FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admin manage stores"
  ON stores FOR ALL
  TO authenticated
  USING (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  )
  WITH CHECK (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  );

CREATE POLICY "Stores manage themselves"
  ON stores FOR UPDATE
  TO authenticated
  USING (
    store_user_id = auth.uid()
  )
  WITH CHECK (
    store_user_id = auth.uid()
  );

-- Recreate policies for orders
CREATE POLICY "Public read access for orders"
  ON orders FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admin manage orders"
  ON orders FOR ALL
  TO authenticated
  USING (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  )
  WITH CHECK (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  );

CREATE POLICY "Stores manage their orders"
  ON orders FOR ALL
  TO authenticated
  USING (
    store_number IN (
      SELECT stores.store_number FROM stores WHERE stores.store_user_id = auth.uid()
    )
  )
  WITH CHECK (
    store_number IN (
      SELECT stores.store_number FROM stores WHERE stores.store_user_id = auth.uid()
    )
  );

CREATE POLICY "Drivers manage assigned orders"
  ON orders FOR UPDATE
  TO authenticated
  USING (
    driver_number IN (
      SELECT drivers.driver_number FROM drivers WHERE drivers.driver_user_id = auth.uid()
    )
  )
  WITH CHECK (
    driver_number IN (
      SELECT drivers.driver_number FROM drivers WHERE drivers.driver_user_id = auth.uid()
    )
  );