import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { AdminDashboard } from './pages/AdminDashboard';
import { DriverDashboard } from './pages/DriverDashboard';
import { StoreDashboard } from './pages/StoreDashboard';
import { OrdersList } from './pages/OrdersList';
import { Login } from './pages/Login';
import { DriverLogin } from './pages/DriverLogin';
import { StoreLogin } from './pages/StoreLogin';
import { ProtectedRoute } from './components/ProtectedRoute';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/driver/login" element={<DriverLogin />} />
        <Route path="/store/login" element={<StoreLogin />} />
        
        <Route path="/" element={<Layout />}>
          <Route index element={<Navigate to="/login" replace />} />
          <Route 
            path="admin" 
            element={
              <ProtectedRoute requiredRole="admin">
                <AdminDashboard />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="driver/dashboard" 
            element={
              <ProtectedRoute requiredRole="driver">
                <DriverDashboard />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="store/dashboard" 
            element={
              <ProtectedRoute requiredRole="store">
                <StoreDashboard />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="orders" 
            element={
              <ProtectedRoute requiredRole="admin">
                <OrdersList />
              </ProtectedRoute>
            } 
          />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;