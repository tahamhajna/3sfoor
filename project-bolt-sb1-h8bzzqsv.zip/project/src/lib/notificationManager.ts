import { supabase } from './supabase';
import { Order } from '../types';

class NotificationManager {
  private hasPermission: boolean = false;
  private subscription: any = null;

  async init() {
    if (!('Notification' in window)) {
      console.log('This browser does not support notifications');
      return false;
    }

    if (Notification.permission === 'granted') {
      this.hasPermission = true;
      return true;
    }

    if (Notification.permission !== 'denied') {
      const permission = await Notification.requestPermission();
      this.hasPermission = permission === 'granted';
      return this.hasPermission;
    }

    return false;
  }

  subscribeToNewOrders() {
    if (!this.hasPermission) return;

    // Unsubscribe from any existing subscription
    if (this.subscription) {
      this.subscription.unsubscribe();
    }

    this.subscription = supabase
      .channel('new-orders')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'orders',
          filter: 'status=eq.pending'
        },
        (payload: { new: Order }) => {
          this.showNotification(payload.new);
        }
      )
      .subscribe();
  }

  unsubscribe() {
    if (this.subscription) {
      this.subscription.unsubscribe();
      this.subscription = null;
    }
  }

  private showNotification(order: Order) {
    if (!this.hasPermission) return;

    const notification = new Notification('New Order Available!', {
      body: `From: ${order.pickup_address}\nTo: ${order.delivery_address}\nPrice: ₪${order.delivery_price}`,
      icon: '/vite.svg', // You can replace this with your app's icon
      badge: '/vite.svg',
      vibrate: [200, 100, 200],
      tag: `order-${order.order_number}`,
      renotify: true
    });

    notification.onclick = () => {
      window.focus();
      notification.close();
    };
  }
}

export const notificationManager = new NotificationManager();