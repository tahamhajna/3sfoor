import { supabase } from './supabase';

export type UserRole = 'admin' | 'driver' | 'store';

interface SessionInfo {
  role: UserRole;
  id: string;
  number?: number; // Add number field for driver/store number
}

let cachedSession: SessionInfo | null = null;

export const sessionManager = {
  async getSession(): Promise<SessionInfo | null> {
    // Return cached session if available
    if (cachedSession) {
      return cachedSession;
    }

    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return null;

    const email = session.user.email;
    if (!email) return null;

    // Check if admin
    if (email.endsWith('@admin.local')) {
      const username = email.split('@')[0];
      const { data: isAdmin } = await supabase.rpc('check_admin_status', {
        check_username: username
      });
      if (isAdmin) {
        cachedSession = { role: 'admin', id: session.user.id };
        return cachedSession;
      }
    }

    // Check if driver
    if (email.startsWith('driver.')) {
      const { data: driver } = await supabase
        .from('drivers')
        .select('driver_number')
        .eq('driver_user_id', session.user.id)
        .single();
      
      if (driver) {
        cachedSession = { 
          role: 'driver', 
          id: session.user.id,
          number: driver.driver_number 
        };
        return cachedSession;
      }
    }

    // Check if store
    const { data: store } = await supabase
      .from('stores')
      .select('store_number')
      .eq('store_user_id', session.user.id)
      .single();
    
    if (store) {
      cachedSession = { 
        role: 'store', 
        id: session.user.id,
        number: store.store_number 
      };
      return cachedSession;
    }

    return null;
  },

  async signOut() {
    cachedSession = null;
    await supabase.auth.signOut();
  },

  clearCache() {
    cachedSession = null;
  }
};