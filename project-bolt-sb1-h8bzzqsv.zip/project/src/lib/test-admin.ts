import { supabase } from './supabase';

export async function testAdminDriverCreation() {
  try {
    // Get current user
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    
    if (userError) {
      console.error('Error getting user:', userError);
      return { success: false, error: userError.message };
    }

    if (!user) {
      return { success: false, error: 'No user logged in' };
    }

    // Test driver creation
    const testDriver = {
      name: 'Test Driver',
      phone: '1234567890',
      driver_user_id: user.id,
      is_active: false
    };

    const { data, error } = await supabase
      .from('drivers')
      .insert([testDriver])
      .select()
      .single();

    if (error) {
      console.error('Error creating driver:', error);
      return { success: false, error: error.message };
    }

    if (data) {
      // Clean up test data
      await supabase
        .from('drivers')
        .delete()
        .eq('id', data.id);
        
      return { success: true, message: 'Admin permissions working correctly' };
    }

    return { success: false, error: 'Unknown error occurred' };
  } catch (err) {
    console.error('Test failed:', err);
    return { success: false, error: err instanceof Error ? err.message : 'Unknown error' };
  }
}