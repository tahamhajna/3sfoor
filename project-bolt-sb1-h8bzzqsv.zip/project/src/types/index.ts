export interface Driver {
  driver_number: number;
  driver_user_id: string;
  name: string;
  phone: string;
  driver_code: string;
  is_active: boolean;
  blocked: boolean;
  created_at: string;
}

export interface Store {
  store_number: number;
  store_user_id: string;
  name: string;
  address: string;
  phone: string;
  blocked: boolean;
  created_at: string;
}

export interface Order {
  order_number: number;
  store_number: number;
  driver_number: number | null;
  pickup_address: string;
  delivery_address: string;
  description?: string;
  delivery_price: number;
  status: 'pending' | 'waiting_for_delivery' | 'picked_up' | 'delivered' | 'cancelled';
  created_at: string;
  updated_at: string;
  store?: Store;
  driver?: Driver;
}