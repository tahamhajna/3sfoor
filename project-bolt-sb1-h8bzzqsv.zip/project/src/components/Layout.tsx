import React from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { Bird, LogOut } from 'lucide-react';
import { sessionManager } from '../lib/sessionManager';

export function Layout() {
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await sessionManager.signOut();
    navigate('/login');
  };

  // Get the base path to determine which navigation to show
  const basePath = location.pathname.split('/')[1];
  const isAdminSection = basePath === 'admin' || basePath === 'orders';

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between h-16">
            <div className="flex">
              <Link to={isAdminSection ? '/admin' : '/'} className="flex items-center px-2 py-2 text-gray-700">
                <Bird className="h-6 w-6" />
                <span className="ml-2 font-semibold">3sfoor</span>
              </Link>
              {isAdminSection && (
                <div className="ml-10 flex space-x-4">
                  <Link
                    to="/admin"
                    className={`flex items-center px-3 py-2 rounded-md text-sm font-medium ${
                      location.pathname === '/admin'
                        ? 'bg-gray-900 text-white'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    Admin
                  </Link>
                  <Link
                    to="/orders"
                    className={`flex items-center px-3 py-2 rounded-md text-sm font-medium ${
                      location.pathname === '/orders'
                        ? 'bg-gray-900 text-white'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    Orders
                  </Link>
                </div>
              )}
            </div>
            {location.pathname !== '/login' && 
             location.pathname !== '/driver/login' && 
             location.pathname !== '/store/login' && (
              <div className="flex items-center">
                <button
                  onClick={handleLogout}
                  className="flex items-center px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </nav>
      <main className="max-w-7xl mx-auto px-4 py-6">
        <Outlet />
      </main>
    </div>
  );
}