import React, { useState, useEffect } from 'react';
import { Calendar } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { formatDateTime } from '../lib/dateUtils';
import { Order } from '../types';

interface DayStats {
  date: string;
  total: number;
  orders: Order[];
}

export function DriverStatistics({ driverNumber }: { driverNumber: number }) {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [todayStats, setTodayStats] = useState<DayStats | null>(null);
  const [selectedDateStats, setSelectedDateStats] = useState<DayStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      setLoading(true);
      try {
        // Get today's date in YYYY-MM-DD format
        const today = new Date().toISOString().split('T')[0];
        
        // Fetch today's orders
        const { data: todayOrders } = await supabase
          .from('orders')
          .select('*')
          .eq('driver_number', driverNumber)
          .eq('status', 'delivered')
          .gte('created_at', today)
          .lt('created_at', new Date(new Date().setDate(new Date().getDate() + 1)).toISOString());

        // Fetch selected date orders
        const { data: selectedDateOrders } = await supabase
          .from('orders')
          .select('*')
          .eq('driver_number', driverNumber)
          .eq('status', 'delivered')
          .gte('created_at', selectedDate)
          .lt('created_at', new Date(new Date(selectedDate).setDate(new Date(selectedDate).getDate() + 1)).toISOString());

        // Process today's stats
        setTodayStats({
          date: today,
          total: todayOrders?.reduce((sum, order) => sum + order.delivery_price, 0) || 0,
          orders: todayOrders || []
        });

        // Process selected date stats
        setSelectedDateStats({
          date: selectedDate,
          total: selectedDateOrders?.reduce((sum, order) => sum + order.delivery_price, 0) || 0,
          orders: selectedDateOrders || []
        });
      } catch (error) {
        console.error('Error fetching statistics:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, [driverNumber, selectedDate]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-48">
        <div className="text-gray-500">Loading statistics...</div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Today's Stats */}
      <section className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold mb-4">Today's Earnings</h3>
        <div className="text-3xl font-bold text-green-600">₪{todayStats?.total.toFixed(2)}</div>
        <div className="text-sm text-gray-500 mt-1">
          From {todayStats?.orders.length} delivered orders
        </div>
      </section>

      {/* Date Selector and Stats */}
      <section className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Orders by Date</h3>
          <div className="flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-gray-400" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            />
          </div>
        </div>
        <div className="text-2xl font-bold text-green-600 mb-4">
          ₪{selectedDateStats?.total.toFixed(2)}
        </div>
        {selectedDateStats?.orders.length === 0 ? (
          <p className="text-gray-500">No delivered orders on this date</p>
        ) : (
          <div className="space-y-4">
            {selectedDateStats?.orders.map(order => (
              <div key={order.order_number} className="border-b pb-4">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="font-medium">Order #{order.order_number}</div>
                    <div className="text-sm text-gray-500">{formatDateTime(order.created_at)}</div>
                  </div>
                  <div className="font-semibold">₪{order.delivery_price.toFixed(2)}</div>
                </div>
                <div className="mt-2 text-sm text-gray-600">
                  <div>From: {order.pickup_address}</div>
                  <div>To: {order.delivery_address}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}