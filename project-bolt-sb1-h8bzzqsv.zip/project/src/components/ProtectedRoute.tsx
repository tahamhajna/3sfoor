import React, { useEffect, useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { sessionManager, UserRole } from '../lib/sessionManager';

interface Props {
  children: React.ReactNode;
  requiredRole?: UserRole;
}

export function ProtectedRoute({ children, requiredRole }: Props) {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [userRole, setUserRole] = useState<UserRole | null>(null);
  const location = useLocation();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const session = await sessionManager.getSession();
        if (!session) {
          setIsAuthenticated(false);
          return;
        }

        if (requiredRole && session.role !== requiredRole) {
          setIsAuthenticated(false);
          return;
        }

        setUserRole(session.role);
        setIsAuthenticated(true);
      } catch (error) {
        console.error('Error checking authentication:', error);
        setIsAuthenticated(false);
      }
    };

    // Only check auth if we don't have a state yet or if the role doesn't match
    if (isAuthenticated === null || (requiredRole && userRole !== requiredRole)) {
      checkAuth();
    }
  }, [requiredRole, isAuthenticated, userRole]);

  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg text-gray-600">Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    // Redirect to appropriate login page based on the required role or current path
    const role = requiredRole || location.pathname.split('/')[1];
    const loginPath = role === 'admin' ? '/login' : `/${role}/login`;
    return <Navigate to={loginPath} replace />;
  }

  return <>{children}</>;
}