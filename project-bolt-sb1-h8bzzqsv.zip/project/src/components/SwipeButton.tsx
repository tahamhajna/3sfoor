import React, { useState, useRef, useEffect } from 'react';

interface SwipeButtonProps {
  onComplete: () => void;
  disabled?: boolean;
  text?: string;
  loadingText?: string;
  className?: string;
}

export function SwipeButton({
  onComplete,
  disabled = false,
  text = 'Swipe to accept',
  loadingText = 'Processing...',
  className = ''
}: SwipeButtonProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [position, setPosition] = useState(0);
  const [width, setWidth] = useState(0);
  const [isCompleted, setIsCompleted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const knobRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (containerRef.current) {
      setWidth(containerRef.current.offsetWidth);
    }
  }, []);

  const handleTouchStart = (e: React.TouchEvent) => {
    if (disabled || isLoading) return;
    setIsDragging(true);
    const touch = e.touches[0];
    const knob = knobRef.current;
    if (knob) {
      const rect = knob.getBoundingClientRect();
      const offset = touch.clientX - rect.left;
      knob.style.transition = 'none';
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging || disabled || isLoading) return;
    const touch = e.touches[0];
    const container = containerRef.current;
    if (container) {
      const rect = container.getBoundingClientRect();
      let newPosition = touch.clientX - rect.left;
      newPosition = Math.max(0, Math.min(newPosition, width - 64)); // 64 is knob width
      setPosition(newPosition);
    }
  };

  const handleTouchEnd = async () => {
    if (disabled || isLoading) return;
    setIsDragging(false);
    const threshold = width * 0.9; // 90% of the width
    if (position > threshold && !isCompleted) {
      setIsCompleted(true);
      setIsLoading(true);
      try {
        await onComplete();
      } finally {
        setIsLoading(false);
        // Reset after a delay
        setTimeout(() => {
          setPosition(0);
          setIsCompleted(false);
        }, 1000);
      }
    } else {
      setPosition(0);
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (disabled || isLoading) return;
    setIsDragging(true);
    const knob = knobRef.current;
    if (knob) {
      const rect = knob.getBoundingClientRect();
      const offset = e.clientX - rect.left;
      knob.style.transition = 'none';
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || disabled || isLoading) return;
    const container = containerRef.current;
    if (container) {
      const rect = container.getBoundingClientRect();
      let newPosition = e.clientX - rect.left;
      newPosition = Math.max(0, Math.min(newPosition, width - 64));
      setPosition(newPosition);
    }
  };

  const handleMouseUp = async () => {
    if (disabled || isLoading) return;
    setIsDragging(false);
    const threshold = width * 0.9;
    if (position > threshold && !isCompleted) {
      setIsCompleted(true);
      setIsLoading(true);
      try {
        await onComplete();
      } finally {
        setIsLoading(false);
        setTimeout(() => {
          setPosition(0);
          setIsCompleted(false);
        }, 1000);
      }
    } else {
      setPosition(0);
    }
  };

  useEffect(() => {
    if (!isDragging) {
      const knob = knobRef.current;
      if (knob) {
        knob.style.transition = 'transform 0.2s ease-out';
      }
    }
  }, [isDragging]);

  const progressPercent = (position / (width - 64)) * 100;

  return (
    <div
      ref={containerRef}
      className={`relative h-12 rounded-full bg-gray-100 overflow-hidden select-none ${
        disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'
      } ${className}`}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Progress bar */}
      <div
        className="absolute inset-0 bg-green-100 transition-transform duration-100"
        style={{ transform: `translateX(${-100 + progressPercent}%)` }}
      />

      {/* Text */}
      <div className="absolute inset-0 flex items-center justify-center text-sm font-medium text-gray-600">
        {isLoading ? loadingText : text}
      </div>

      {/* Knob */}
      <div
        ref={knobRef}
        className={`absolute left-0 top-0 w-16 h-full bg-green-600 rounded-full shadow-lg flex items-center justify-center transition-colors ${
          isCompleted ? 'bg-green-700' : ''
        }`}
        style={{ transform: `translateX(${position}px)` }}
        onMouseDown={handleMouseDown}
        onTouchStart={handleTouchStart}
      >
        <div className="w-2 h-2 bg-white rounded-full" />
        <div className="w-2 h-2 bg-white rounded-full mx-1" />
        <div className="w-2 h-2 bg-white rounded-full" />
      </div>
    </div>
  );
}