import { create } from 'zustand';
import { Driver, Store, Order } from '../types';
import { supabase } from '../lib/supabase';
import { sessionManager } from '../lib/sessionManager';

interface AppState {
  drivers: Driver[];
  stores: Store[];
  orders: Order[];
  user: any | null;
  isAdmin: boolean;
  loading: boolean;
  fetchDrivers: () => Promise<void>;
  fetchStores: () => Promise<void>;
  fetchOrders: () => Promise<void>;
  checkAdminStatus: () => Promise<boolean>;
  updateDriverStatus: (driverNumber: number, isActive: boolean) => Promise<void>;
  updateDriverBlocked: (driverNumber: number, blocked: boolean) => Promise<void>;
  updateStoreBlocked: (storeNumber: number, blocked: boolean) => Promise<void>;
  createOrder: (orderData: Partial<Order>) => Promise<void>;
  updateOrderStatus: (orderNumber: number, status: Order['status']) => Promise<void>;
  acceptOrder: (orderNumber: number, driverNumber: number) => Promise<void>;
  deleteOrder: (orderNumber: number) => Promise<void>;
  updateOrderDriver: (orderNumber: number, driverNumber: number | null) => Promise<void>;
  updateOrderPrice: (orderNumber: number, price: number) => Promise<void>;
}

export const useStore = create<AppState>((set, get) => ({
  drivers: [],
  stores: [],
  orders: [],
  user: null,
  isAdmin: false,
  loading: false,

  fetchDrivers: async () => {
    const { data } = await supabase
      .from('drivers')
      .select('*')
      .order('driver_number', { ascending: true });
    if (data) set({ drivers: data });
  },

  fetchStores: async () => {
    const { data } = await supabase
      .from('stores')
      .select('*')
      .order('store_number', { ascending: true });
    if (data) set({ stores: data });
  },

  fetchOrders: async () => {
    const { data } = await supabase
      .from('orders')
      .select(`
        *,
        store:stores(
          store_number,
          name,
          address,
          phone,
          blocked
        ),
        driver:drivers(
          driver_number,
          name,
          phone,
          is_active,
          blocked
        )
      `)
      .order('created_at', { ascending: false });
    if (data) set({ orders: data });
  },

  checkAdminStatus: async () => {
    try {
      const session = await sessionManager.getSession();
      const isAdmin = session?.role === 'admin';
      set({ isAdmin });
      return isAdmin;
    } catch (error) {
      console.error('Error checking admin status:', error);
      return false;
    }
  },

  updateDriverStatus: async (driverNumber: number, isActive: boolean) => {
    const { error } = await supabase
      .from('drivers')
      .update({ is_active: isActive })
      .eq('driver_number', driverNumber);
    
    if (error) {
      console.error('Error updating driver status:', error);
      throw new Error(error.message);
    }
    await get().fetchDrivers();
  },

  updateDriverBlocked: async (driverNumber: number, blocked: boolean) => {
    const { error } = await supabase
      .from('drivers')
      .update({ blocked })
      .eq('driver_number', driverNumber);
    
    if (error) {
      console.error('Error updating driver blocked status:', error);
      throw new Error(error.message);
    }
    await get().fetchDrivers();
  },

  updateStoreBlocked: async (storeNumber: number, blocked: boolean) => {
    const { error } = await supabase
      .from('stores')
      .update({ blocked })
      .eq('store_number', storeNumber);
    
    if (error) {
      console.error('Error updating store blocked status:', error);
      throw new Error(error.message);
    }
    await get().fetchStores();
  },

  createOrder: async (orderData: Partial<Order>) => {
    const { error } = await supabase
      .from('orders')
      .insert([orderData]);
    
    if (error) {
      console.error('Error creating order:', error);
      throw new Error(error.message);
    }
    await get().fetchOrders();
  },

  updateOrderStatus: async (orderNumber: number, status: Order['status']) => {
    const { error } = await supabase
      .from('orders')
      .update({ 
        status, 
        updated_at: new Date().toISOString() 
      })
      .eq('order_number', orderNumber);
    
    if (error) {
      console.error('Error updating order status:', error);
      throw new Error(error.message);
    }
    await get().fetchOrders();
  },

  acceptOrder: async (orderNumber: number, driverNumber: number) => {
    if (!orderNumber || typeof orderNumber !== 'number') {
      throw new Error('Invalid order number');
    }
    if (!driverNumber || typeof driverNumber !== 'number') {
      throw new Error('Invalid driver number');
    }

    try {
      const { data: driver, error: driverError } = await supabase
        .from('drivers')
        .select('is_active, blocked')
        .eq('driver_number', driverNumber)
        .single();

      if (driverError) {
        throw new Error(`Failed to verify driver status: ${driverError.message}`);
      }
      if (!driver) {
        throw new Error('Driver not found');
      }
      if (!driver.is_active) {
        throw new Error('You must be active to accept orders');
      }
      if (driver.blocked) {
        throw new Error('Your account is currently blocked');
      }

      const { data: updatedOrder, error: updateError } = await supabase
        .rpc('accept_order', {
          p_order_number: orderNumber,
          p_driver_number: driverNumber
        });

      if (updateError) {
        if (updateError.message.includes('not found')) {
          throw new Error('Order not found or no longer available');
        }
        throw new Error(updateError.message);
      }

      if (!updatedOrder || updatedOrder.length === 0) {
        throw new Error('Order is no longer available');
      }

      await get().fetchOrders();
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to accept order';
      console.error('Error accepting order:', errorMessage);
      throw new Error(errorMessage);
    }
  },

  deleteOrder: async (orderNumber: number) => {
    const { error } = await supabase
      .from('orders')
      .delete()
      .eq('order_number', orderNumber);
    
    if (error) {
      console.error('Error deleting order:', error);
      throw new Error(error.message);
    }
    await get().fetchOrders();
  },

  updateOrderDriver: async (orderNumber: number, driverNumber: number | null) => {
    const { error } = await supabase
      .from('orders')
      .update({ 
        driver_number: driverNumber,
        updated_at: new Date().toISOString()
      })
      .eq('order_number', orderNumber);
    
    if (error) {
      console.error('Error updating order driver:', error);
      throw new Error(error.message);
    }
    await get().fetchOrders();
  },

  updateOrderPrice: async (orderNumber: number, price: number) => {
    if (price < 0) {
      throw new Error('Price cannot be negative');
    }

    const { error } = await supabase
      .from('orders')
      .update({ 
        delivery_price: price,
        updated_at: new Date().toISOString()
      })
      .eq('order_number', orderNumber);
    
    if (error) {
      console.error('Error updating order price:', error);
      throw new Error(error.message);
    }
    await get().fetchOrders();
  }
}));