import React, { useState, useEffect } from 'react';
import { useStore } from '../store';
import { Package, BarChart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { sessionManager } from '../lib/sessionManager';
import { formatDateTime } from '../lib/dateUtils';
import { DriverStatistics } from '../components/DriverStatistics';

export function DriverDashboard() {
  const { orders, drivers, fetchDrivers, fetchOrders, updateOrderStatus, acceptOrder } = useStore();
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();
  const [currentDriver, setCurrentDriver] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [processingOrderNumber, setProcessingOrderNumber] = useState<number | null>(null);
  const [showStats, setShowStats] = useState(false);

  useEffect(() => {
    const initializeDriver = async () => {
      try {
        const session = await sessionManager.getSession();
        if (!session || session.role !== 'driver' || !session.number) {
          navigate('/driver/login');
          return;
        }

        const { data: driver, error } = await supabase
          .from('drivers')
          .select('*')
          .eq('driver_number', session.number)
          .single();

        if (error || !driver) {
          console.error('Error fetching driver:', error);
          navigate('/driver/login');
          return;
        }

        setCurrentDriver(driver);
        await Promise.all([fetchOrders(), fetchDrivers()]);
      } catch (err) {
        console.error('Error initializing driver:', err);
        navigate('/driver/login');
      } finally {
        setIsLoading(false);
      }
    };

    initializeDriver();

    const ordersSubscription = supabase
      .channel('orders')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'orders' },
        () => {
          fetchOrders();
        }
      )
      .subscribe();

    return () => {
      ordersSubscription.unsubscribe();
    };
  }, [navigate, fetchOrders, fetchDrivers]);

  const handleStatusToggle = async () => {
    if (!currentDriver) return;

    try {
      await useStore.getState().updateDriverStatus(currentDriver.driver_number, !currentDriver.is_active);
      setCurrentDriver(prev => ({ ...prev, is_active: !prev.is_active }));
      setSuccess(`Status updated to ${!currentDriver.is_active ? 'active' : 'inactive'}`);
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error('Error updating status:', err);
      setError(err instanceof Error ? err.message : 'Failed to update status');
      setTimeout(() => setError(''), 3000);
    }
  };

  const handleAcceptOrder = async (orderNumber: number) => {
    if (!currentDriver?.is_active) {
      setError('You must be active to accept orders');
      setTimeout(() => setError(''), 3000);
      return;
    }

    if (processingOrderNumber !== null) {
      setError('Please wait while processing the current order');
      return;
    }

    try {
      setProcessingOrderNumber(orderNumber);
      setError('');
      await acceptOrder(orderNumber, currentDriver.driver_number);
      setSuccess('Order accepted successfully');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error('Error accepting order:', err);
      setError(err instanceof Error ? err.message : 'Unable to accept order at this time');
      setTimeout(() => setError(''), 3000);
    } finally {
      setProcessingOrderNumber(null);
    }
  };

  const handleUpdateStatus = async (orderNumber: number, status: string) => {
    try {
      setError('');
      await updateOrderStatus(orderNumber, status);
      setSuccess(`Order status updated to ${status.replace(/_/g, ' ')}`);
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error('Error updating order status:', err);
      setError(err instanceof Error ? err.message : 'Failed to update order status');
      setTimeout(() => setError(''), 3000);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg text-gray-600">Loading...</div>
      </div>
    );
  }

  if (!currentDriver) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg text-gray-600">No driver information found</div>
      </div>
    );
  }

  const driverOrders = orders.filter((order) => order.driver_number === currentDriver?.driver_number);
  const availableOrders = currentDriver?.is_active && !currentDriver?.blocked ? 
    orders.filter((order) => order.status === 'pending' && !order.driver_number) :
    [];

  return (
    <div className="space-y-8 p-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Driver Dashboard</h1>
          <p className="text-gray-600">Welcome back, {currentDriver.name}</p>
        </div>
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setShowStats(!showStats)}
            className={`flex items-center px-4 py-2 rounded-md ${
              showStats ? 'bg-indigo-100 text-indigo-700' : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
            }`}
            title={showStats ? 'Hide Statistics' : 'Show Statistics'}
          >
            <BarChart className="w-5 h-5 mr-2" />
            <span>Statistics</span>
          </button>
          <button
            onClick={handleStatusToggle}
            className={`px-4 py-2 rounded-md ${
              currentDriver.is_active
                ? 'bg-red-600 hover:bg-red-700'
                : 'bg-green-600 hover:bg-green-700'
            } text-white`}
          >
            {currentDriver.is_active ? 'Go Offline' : 'Go Online'}
          </button>
        </div>
      </div>

      {(error || success) && (
        <div className={`p-4 rounded-md ${
          error ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700'
        }`}>
          {error || success}
        </div>
      )}

      {showStats ? (
        <DriverStatistics driverNumber={currentDriver.driver_number} />
      ) : (
        <>
          {currentDriver.is_active && !currentDriver.blocked && (
            <section>
              <h2 className="text-xl font-semibold mb-4">Available Orders</h2>
              {availableOrders.length === 0 ? (
                <p className="text-gray-500">No orders available at the moment</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {availableOrders.map((order) => (
                    <div
                      key={order.order_number}
                      className="bg-white p-4 rounded-lg shadow space-y-4"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-medium">Order #{order.order_number}</h3>
                          <p className="text-sm text-gray-500">
                            From: {order.store?.name}
                          </p>
                        </div>
                        <Package className="w-6 h-6 text-gray-400" />
                      </div>
                      <div className="space-y-2">
                        <p className="text-sm">
                          <strong>Pickup:</strong> {order.pickup_address}
                        </p>
                        <p className="text-sm">
                          <strong>Delivery:</strong> {order.delivery_address}
                        </p>
                        <p className="text-sm">
                          <strong>Delivery Price:</strong> ₪{order.delivery_price.toFixed(2)}
                        </p>
                        <p className="text-sm text-gray-500">
                          Created: {formatDateTime(order.created_at)}
                        </p>
                      </div>
                      <button
                        onClick={() => handleAcceptOrder(order.order_number)}
                        disabled={processingOrderNumber === order.order_number}
                        className={`w-full ${
                          processingOrderNumber === order.order_number
                            ? 'bg-gray-400 cursor-not-allowed'
                            : 'bg-green-600 hover:bg-green-700'
                        } text-white py-2 rounded-md transition-colors`}
                      >
                        {processingOrderNumber === order.order_number ? 'Processing...' : 'Accept Order'}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </section>
          )}

          <section>
            <h2 className="text-xl font-semibold mb-4">My Orders</h2>
            {driverOrders.length === 0 ? (
              <p className="text-gray-500">You haven't accepted any orders yet</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {driverOrders.map((order) => (
                  <div
                    key={order.order_number}
                    className="bg-white p-4 rounded-lg shadow space-y-4"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium">Order #{order.order_number}</h3>
                        <p className="text-sm text-gray-500">
                          From: {order.store?.name}
                        </p>
                      </div>
                      <span
                        className={`px-2 py-1 text-xs font-semibold rounded-full ${
                          order.status === 'delivered'
                            ? 'bg-green-100 text-green-800'
                            : order.status === 'picked_up'
                            ? 'bg-blue-100 text-blue-800'
                            : order.status === 'waiting_for_delivery'
                            ? 'bg-yellow-100 text-yellow-800'
                            : order.status === 'cancelled'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}
                      >
                        {order.status.replace(/_/g, ' ')}
                      </span>
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm">
                        <strong>Pickup:</strong> {order.pickup_address}
                      </p>
                      <p className="text-sm">
                        <strong>Delivery:</strong> {order.delivery_address}
                      </p>
                      {order.description && (
                        <p className="text-sm">
                          <strong>Description:</strong> {order.description}
                        </p>
                      )}
                      <p className="text-sm">
                        <strong>Delivery Price:</strong> ₪{order.delivery_price.toFixed(2)}
                      </p>
                      <p className="text-sm text-gray-500">
                        Created: {formatDateTime(order.created_at)}
                      </p>
                      {order.updated_at !== order.created_at && (
                        <p className="text-sm text-gray-500">
                          Last Update: {formatDateTime(order.updated_at)}
                        </p>
                      )}
                    </div>
                    {!currentDriver.blocked && order.status === 'waiting_for_delivery' && (
                      <button
                        onClick={() => handleUpdateStatus(order.order_number, 'picked_up')}
                        className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700"
                      >
                        Start Delivery
                      </button>
                    )}
                    {!currentDriver.blocked && order.status === 'picked_up' && (
                      <button
                        onClick={() => handleUpdateStatus(order.order_number, 'delivered')}
                        className="w-full bg-green-600 text-white py-2 rounded-md hover:bg-green-700"
                      >
                        Mark as Delivered
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </section>
        </>
      )}
    </div>
  );
}