import React, { useState, useEffect } from 'react';
import { useStore } from '../store';
import { Plus, X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useNavigate } from 'react-router-dom';
import { sessionManager } from '../lib/sessionManager';
import { formatDateTime } from '../lib/dateUtils';

export function StoreDashboard() {
  const { orders, createOrder, fetchOrders } = useStore();
  const [showOrderForm, setShowOrderForm] = useState(false);
  const [newOrder, setNewOrder] = useState({
    pickup_address: '',
    delivery_address: '',
    description: '',
    delivery_price: 15
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [currentStore, setCurrentStore] = useState<any>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const checkStore = async () => {
      const session = await sessionManager.getSession();
      if (!session || session.role !== 'store' || !session.number) {
        navigate('/store/login');
        return;
      }

      const { data: store, error } = await supabase
        .from('stores')
        .select('*')
        .eq('store_number', session.number)
        .single();

      if (error || !store) {
        console.error('Error fetching store:', error);
        navigate('/store/login');
        return;
      }

      setCurrentStore(store);
      setNewOrder(prev => ({
        ...prev,
        pickup_address: `${store.name}, ${store.address}`
      }));
    };

    checkStore();
    fetchOrders();

    const ordersSubscription = supabase
      .channel('orders')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'orders' },
        () => {
          fetchOrders();
        }
      )
      .subscribe();

    return () => {
      ordersSubscription.unsubscribe();
    };
  }, [fetchOrders, navigate]);

  const handleCreateOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (!currentStore) {
        setError('Store information not found');
        return;
      }

      if (currentStore.blocked) {
        setError('Unable to create new orders at this time');
        return;
      }

      await createOrder({
        store_number: currentStore.store_number,
        pickup_address: newOrder.pickup_address,
        delivery_address: newOrder.delivery_address,
        description: newOrder.description,
        delivery_price: newOrder.delivery_price,
        status: 'pending',
      });
      setNewOrder({
        pickup_address: `${currentStore.name}, ${currentStore.address}`,
        delivery_address: '',
        description: '',
        delivery_price: 15
      });
      setShowOrderForm(false);
      setSuccess('Order created successfully');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error('Error creating order:', err);
      setError('Failed to create order');
      setTimeout(() => setError(''), 3000);
    }
  };

  const storeOrders = orders.filter((order) => order.store_number === currentStore?.store_number);

  if (!currentStore) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg text-gray-600">Loading...</div>
      </div>
    );
  }

  return (
    <div className="space-y-8 p-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Store Dashboard</h1>
          <p className="text-gray-600">Welcome back, {currentStore.name}</p>
        </div>
        {!currentStore.blocked && (
          <button
            onClick={() => setShowOrderForm(true)}
            className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Order
          </button>
        )}
      </div>

      {(error || success) && (
        <div className={`p-4 rounded-md ${
          error ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700'
        }`}>
          {error || success}
        </div>
      )}

      <section>
        <h2 className="text-xl font-semibold mb-4">My Orders</h2>
        {storeOrders.length === 0 ? (
          <p className="text-gray-500">No orders yet. Create your first order!</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {storeOrders.map((order) => (
              <div
                key={order.order_number}
                className="bg-white p-4 rounded-lg shadow space-y-4"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-medium">Order #{order.order_number}</h3>
                    <p className="text-sm text-gray-500">
                      Driver: {order.driver ? order.driver.name : 'Unassigned'}
                    </p>
                  </div>
                  <span
                    className={`px-2 py-1 text-xs font-semibold rounded-full ${
                      order.status === 'delivered'
                        ? 'bg-green-100 text-green-800'
                        : order.status === 'picked_up'
                        ? 'bg-blue-100 text-blue-800'
                        : order.status === 'waiting_for_delivery'
                        ? 'bg-yellow-100 text-yellow-800'
                        : order.status === 'cancelled'
                        ? 'bg-red-100 text-red-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}
                  >
                    {order.status.replace(/_/g, ' ')}
                  </span>
                </div>
                <div className="space-y-2">
                  <p className="text-sm">
                    <strong>Pickup:</strong> {order.pickup_address}
                  </p>
                  <p className="text-sm">
                    <strong>Delivery:</strong> {order.delivery_address}
                  </p>
                  {order.description && (
                    <p className="text-sm">
                      <strong>Description:</strong> {order.description}
                    </p>
                  )}
                  <p className="text-sm">
                    <strong>Delivery Price:</strong> ₪{order.delivery_price.toFixed(2)}
                  </p>
                  <p className="text-sm text-gray-500">
                    Created: {formatDateTime(order.created_at)}
                  </p>
                  {order.updated_at !== order.created_at && (
                    <p className="text-sm text-gray-500">
                      Last Update: {formatDateTime(order.updated_at)}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {showOrderForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">Create New Order</h3>
              <button onClick={() => setShowOrderForm(false)}>
                <X className="w-6 h-6" />
              </button>
            </div>
            <form onSubmit={handleCreateOrder} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Pickup Address
                </label>
                <input
                  type="text"
                  required
                  value={newOrder.pickup_address}
                  onChange={(e) =>
                    setNewOrder({ ...newOrder, pickup_address: e.target.value })
                  }
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Delivery Address
                </label>
                <input
                  type="text"
                  required
                  value={newOrder.delivery_address}
                  onChange={(e) =>
                    setNewOrder({ ...newOrder, delivery_address: e.target.value })
                  }
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Description
                </label>
                <textarea
                  rows={3}
                  value={newOrder.description}
                  onChange={(e) =>
                    setNewOrder({ ...newOrder, description: e.target.value })
                  }
                  placeholder="Add any special instructions or details about the order"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Delivery Price (₪)
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  step="0.01"
                  value={newOrder.delivery_price}
                  onChange={(e) =>
                    setNewOrder({ ...newOrder, delivery_price: parseFloat(e.target.value) })
                  }
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
              <button
                type="submit"
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                Create Order
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}