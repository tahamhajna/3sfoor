import React, { useState, useEffect } from 'react';
import { useStore } from '../store';
import { Plus, X, Edit, Trash2 } from 'lucide-react';
import { supabase } from '../lib/supabase';

function generateDriverCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  return Array.from({ length: 6 }, () => chars.charAt(Math.floor(Math.random() * chars.length))).join('');
}

export function AdminDashboard() {
  const { drivers, stores, fetchDrivers, fetchStores, updateDriverStatus, updateDriverBlocked, updateStoreBlocked } = useStore();
  const [showDriverForm, setShowDriverForm] = useState(false);
  const [showStoreForm, setShowStoreForm] = useState(false);
  const [editingDriver, setEditingDriver] = useState<any>(null);
  const [editingStore, setEditingStore] = useState<any>(null);
  const [newDriver, setNewDriver] = useState({ name: '', phone: '', driver_code: '' });
  const [newStore, setNewStore] = useState({ name: '', address: '', phone: '' });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchDrivers();
    fetchStores();
  }, [fetchDrivers, fetchStores]);

  const handleAddDriver = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        setError('You must be logged in to add a driver');
        return;
      }

      const driverCode = newDriver.driver_code || generateDriverCode();
      const { error: insertError } = await supabase
        .from('drivers')
        .insert([{
          name: newDriver.name,
          phone: newDriver.phone,
          driver_code: driverCode,
          driver_user_id: user.id,
          is_active: false,
          blocked: false
        }]);

      if (insertError) {
        console.error('Insert error:', insertError);
        setError(insertError.message);
        return;
      }

      setNewDriver({ name: '', phone: '', driver_code: '' });
      setShowDriverForm(false);
      fetchDrivers();
      setSuccess(`Driver added successfully. Driver code: ${driverCode}`);
      setTimeout(() => setSuccess(''), 10000);
    } catch (err) {
      console.error('Error adding driver:', err);
      setError('An error occurred while adding the driver');
    } finally {
      setLoading(false);
    }
  };

  const handleEditDriver = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const { error: updateError } = await supabase
        .from('drivers')
        .update({
          name: newDriver.name,
          phone: newDriver.phone,
          driver_code: newDriver.driver_code,
        })
        .eq('driver_number', editingDriver.driver_number);

      if (updateError) {
        console.error('Update error:', updateError);
        setError(updateError.message);
        return;
      }

      setNewDriver({ name: '', phone: '', driver_code: '' });
      setEditingDriver(null);
      setShowDriverForm(false);
      fetchDrivers();
      setSuccess('Driver updated successfully');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error('Error updating driver:', err);
      setError('An error occurred while updating the driver');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteDriver = async (driverNumber: number) => {
    if (!window.confirm('Are you sure you want to delete this driver?')) {
      return;
    }

    setError('');
    setLoading(true);

    try {
      const { error: deleteError } = await supabase
        .from('drivers')
        .delete()
        .eq('driver_number', driverNumber);

      if (deleteError) {
        console.error('Delete error:', deleteError);
        setError(deleteError.message);
        return;
      }

      fetchDrivers();
      setSuccess('Driver deleted successfully');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error('Error deleting driver:', err);
      setError('An error occurred while deleting the driver');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (driverNumber: number, newStatus: boolean) => {
    try {
      await updateDriverStatus(driverNumber, newStatus);
      setSuccess(`Driver status updated successfully`);
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error('Error updating driver status:', err);
      setError('Failed to update driver status');
      setTimeout(() => setError(''), 3000);
    }
  };

  const handleDriverBlockedChange = async (driverNumber: number, newBlocked: boolean) => {
    try {
      await updateDriverBlocked(driverNumber, newBlocked);
      setSuccess(`Driver ${newBlocked ? 'blocked' : 'unblocked'} successfully`);
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error('Error updating driver blocked status:', err);
      setError('Failed to update driver blocked status');
      setTimeout(() => setError(''), 3000);
    }
  };

  const handleStoreBlockedChange = async (storeNumber: number, newBlocked: boolean) => {
    try {
      await updateStoreBlocked(storeNumber, newBlocked);
      setSuccess(`Store ${newBlocked ? 'blocked' : 'unblocked'} successfully`);
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error('Error updating store blocked status:', err);
      setError('Failed to update store blocked status');
      setTimeout(() => setError(''), 3000);
    }
  };

  const handleAddStore = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        setError('You must be logged in to add a store');
        return;
      }

      const { error: insertError } = await supabase
        .from('stores')
        .insert([{
          name: newStore.name,
          address: newStore.address,
          phone: newStore.phone,
          store_user_id: user.id,
          blocked: false
        }]);

      if (insertError) {
        console.error('Insert error:', insertError);
        setError(insertError.message);
        return;
      }

      setNewStore({ name: '', address: '', phone: '' });
      setShowStoreForm(false);
      fetchStores();
      setSuccess('Store added successfully');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error('Error adding store:', err);
      setError('An error occurred while adding the store');
    } finally {
      setLoading(false);
    }
  };

  const handleEditStore = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const { error: updateError } = await supabase
        .from('stores')
        .update({
          name: newStore.name,
          address: newStore.address,
          phone: newStore.phone,
        })
        .eq('store_number', editingStore.store_number);

      if (updateError) {
        console.error('Update error:', updateError);
        setError(updateError.message);
        return;
      }

      setNewStore({ name: '', address: '', phone: '' });
      setEditingStore(null);
      setShowStoreForm(false);
      fetchStores();
      setSuccess('Store updated successfully');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error('Error updating store:', err);
      setError('An error occurred while updating the store');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteStore = async (storeNumber: number) => {
    if (!window.confirm('Are you sure you want to delete this store?')) {
      return;
    }

    setError('');
    setLoading(true);

    try {
      const { error: deleteError } = await supabase
        .from('stores')
        .delete()
        .eq('store_number', storeNumber);

      if (deleteError) {
        console.error('Delete error:', deleteError);
        setError(deleteError.message);
        return;
      }

      fetchStores();
      setSuccess('Store deleted successfully');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error('Error deleting store:', err);
      setError('An error occurred while deleting the store');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>

      {error && (
        <div className="bg-red-50 border-l-4 border-red-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}

      {success && (
        <div className="bg-green-50 border-l-4 border-green-400 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-green-400" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-green-700">{success}</p>
            </div>
          </div>
        </div>
      )}

      <section>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">Drivers</h2>
          <button
            onClick={() => {
              setEditingDriver(null);
              setNewDriver({ name: '', phone: '', driver_code: '' });
              setShowDriverForm(true);
            }}
            className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
            disabled={loading}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Driver
          </button>
        </div>
        <div className="bg-white shadow rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <div className="inline-block min-w-full align-middle">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                      ID
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                      Name
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                      Phone
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                      Driver Code
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                      Status
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                      Blocked
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {drivers.map((driver) => (
                    <tr key={driver.driver_number}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">#{driver.driver_number}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">{driver.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">{driver.phone}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-mono">{driver.driver_code}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <select
                          value={driver.is_active ? 'active' : 'inactive'}
                          onChange={(e) => handleStatusChange(driver.driver_number, e.target.value === 'active')}
                          className={`px-2 py-1 text-sm font-semibold rounded-full ${
                            driver.is_active
                              ? 'bg-green-100 text-green-800'
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          <option value="active">Active</option>
                          <option value="inactive">Inactive</option>
                        </select>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <select
                          value={driver.blocked ? 'blocked' : 'unblocked'}
                          onChange={(e) => handleDriverBlockedChange(driver.driver_number, e.target.value === 'blocked')}
                          className={`px-2 py-1 text-sm font-semibold rounded-full ${
                            driver.blocked
                              ? 'bg-red-100 text-red-800'
                              : 'bg-green-100 text-green-800'
                          }`}
                        >
                          <option value="unblocked">Not Blocked</option>
                          <option value="blocked">Blocked</option>
                        </select>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <div className="flex space-x-2">
                          <button
                            onClick={() => {
                              setEditingDriver(driver);
                              setNewDriver({
                                name: driver.name,
                                phone: driver.phone,
                                driver_code: driver.driver_code,
                              });
                              setShowDriverForm(true);
                            }}
                            className="text-indigo-600 hover:text-indigo-900"
                          >
                            <Edit className="w-5 h-5" />
                          </button>
                          <button
                            onClick={() => handleDeleteDriver(driver.driver_number)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">Stores</h2>
          <button
            onClick={() => {
              setEditingStore(null);
              setNewStore({ name: '', address: '', phone: '' });
              setShowStoreForm(true);
            }}
            className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
            disabled={loading}
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Store
          </button>
        </div>
        <div className="bg-white shadow rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <div className="inline-block min-w-full align-middle">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                      ID
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                      Name
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                      Address
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                      Phone
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                      Blocked
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {stores.map((store) => (
                    <tr key={store.store_number}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">#{store.store_number}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">{store.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">{store.address}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">{store.phone}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <select
                          value={store.blocked ? 'blocked' : 'unblocked'}
                          onChange={(e) => handleStoreBlockedChange(store.store_number, e.target.value === 'blocked')}
                          className={`px-2 py-1 text-sm font-semibold rounded-full ${
                            store.blocked
                              ? 'bg-red-100 text-red-800'
                              : 'bg-green-100 text-green-800'
                          }`}
                        >
                          <option value="unblocked">Not Blocked</option>
                          <option value="blocked">Blocked</option>
                        </select>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <div className="flex space-x-2">
                          <button
                            onClick={() => {
                              setEditingStore(store);
                              setNewStore({
                                name: store.name,
                                address: store.address,
                                phone: store.phone,
                              });
                              setShowStoreForm(true);
                            }}
                            className="text-indigo-600 hover:text-indigo-900"
                          >
                            <Edit className="w-5 h-5" />
                          </button>
                          <button
                            onClick={() => handleDeleteStore(store.store_number)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      {showDriverForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">
                {editingDriver ? 'Edit Driver' : 'Add New Driver'}
              </h3>
              <button onClick={() => {
                setShowDriverForm(false);
                setEditingDriver(null);
                setNewDriver({ name: '', phone: '', driver_code: '' });
              }}>
                <X className="w-6 h-6" />
              </button>
            </div>
            <form onSubmit={editingDriver ? handleEditDriver : handleAddDriver} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Name</label>
                <input
                  type="text"
                  required
                  value={newDriver.name}
                  onChange={(e) => setNewDriver({ ...newDriver, name: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Phone</label>
                <input
                  type="tel"
                  required
                  value={newDriver.phone}
                  onChange={(e) => setNewDriver({ ...newDriver, phone: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Driver Code</label>
                <input
                  type="text"
                  maxLength={6}
                  value={newDriver.driver_code}
                  onChange={(e) => setNewDriver({ ...newDriver, driver_code: e.target.value.toUpperCase() })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 font-mono uppercase"
                  placeholder={editingDriver ? undefined : "Leave empty to auto-generate"}
                  required={!!editingDriver}
                />
                {!editingDriver && (
                  <p className="mt-1 text-sm text-gray-500">
                    Leave empty to auto-generate a random 6-character code
                  </p>
                )}
              </div>
              <button
                type="submit"
                disabled={loading}
                className={`w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${
                  loading ? 'bg-indigo-400 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-700'
                } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500`}
              >
                {loading ? 'Processing...' : editingDriver ? 'Update Driver' : 'Add Driver'}
              </button>
            </form>
          </div>
        </div>
      )}

      {showStoreForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium">
                {editingStore ? 'Edit Store' : 'Add New Store'}
              </h3>
              <button onClick={() => {
                setShowStoreForm(false);
                setEditingStore(null);
                setNewStore({ name: '', address: '', phone: '' });
              }}>
                <X className="w-6 h-6" />
              </button>
            </div>
            <form onSubmit={editingStore ? handleEditStore : handleAddStore} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Name</label>
                <input
                  type="text"
                  required
                  value={newStore.name}
                  onChange={(e) => setNewStore({ ...newStore, name: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Address</label>
                <input
                  type="text"
                  required
                  value={newStore.address}
                  onChange={(e) => setNewStore({ ...newStore, address: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Phone</label>
                <input
                  type="tel"
                  required
                  value={newStore.phone}
                  onChange={(e) => setNewStore({ ...newStore, phone: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className={`w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${
                  loading ? 'bg-indigo-400 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-700'
                } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500`}
              >
                {loading ? 'Processing...' : editingStore ? 'Update Store' : 'Add Store'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}