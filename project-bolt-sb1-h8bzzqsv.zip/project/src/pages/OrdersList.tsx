import React, { useEffect, useState } from 'react';
import { useStore } from '../store';
import { Package, TableIcon, Grid, Trash2, AlertCircle } from 'lucide-react';
import { formatDateTime } from '../lib/dateUtils';
import { Order } from '../types';

const ORDER_STATUSES = [
  'pending',
  'waiting_for_delivery',
  'picked_up',
  'delivered',
  'cancelled'
] as const;

export function OrdersList() {
  const { orders, drivers, fetchOrders, fetchDrivers, deleteOrder, updateOrderDriver, updateOrderPrice, updateOrderStatus } = useStore();
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('table');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [editingPrice, setEditingPrice] = useState<{ orderNumber: number; price: string } | null>(null);
  const [deletingOrder, setDeletingOrder] = useState<number | null>(null);

  useEffect(() => {
    fetchOrders();
    fetchDrivers();
  }, [fetchOrders, fetchDrivers]);

  const handleDeleteOrder = async (orderNumber: number) => {
    try {
      await deleteOrder(orderNumber);
      setSuccess('Order deleted successfully');
      setDeletingOrder(null);
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete order');
      setTimeout(() => setError(''), 3000);
    }
  };

  const handleDriverChange = async (orderNumber: number, driverNumber: string) => {
    try {
      await updateOrderDriver(orderNumber, driverNumber === '' ? null : parseInt(driverNumber));
      setSuccess('Driver updated successfully');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update driver');
      setTimeout(() => setError(''), 3000);
    }
  };

  const handlePriceChange = async (orderNumber: number, price: string) => {
    try {
      const numericPrice = parseFloat(price);
      if (isNaN(numericPrice)) {
        throw new Error('Invalid price');
      }
      await updateOrderPrice(orderNumber, numericPrice);
      setSuccess('Price updated successfully');
      setEditingPrice(null);
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update price');
      setTimeout(() => setError(''), 3000);
    }
  };

  const handleStatusChange = async (orderNumber: number, status: Order['status']) => {
    try {
      await updateOrderStatus(orderNumber, status);
      setSuccess('Status updated successfully');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update status');
      setTimeout(() => setError(''), 3000);
    }
  };

  // Split orders by status
  const activeOrders = orders.filter(order => 
    ['pending', 'waiting_for_delivery', 'picked_up'].includes(order.status)
  );
  const inactiveOrders = orders.filter(order => 
    ['delivered', 'cancelled'].includes(order.status)
  );

  const renderStatusBadge = (order: Order) => (
    <select
      value={order.status}
      onChange={(e) => handleStatusChange(order.order_number, e.target.value as Order['status'])}
      className={`px-2 py-1 text-xs font-semibold rounded-full ${
        order.status === 'delivered'
          ? 'bg-green-100 text-green-800'
          : order.status === 'pending'
          ? 'bg-yellow-100 text-yellow-800'
          : order.status === 'picked_up'
          ? 'bg-blue-100 text-blue-800'
          : order.status === 'cancelled'
          ? 'bg-red-100 text-red-800'
          : 'bg-gray-100 text-gray-800'
      }`}
    >
      {ORDER_STATUSES.map(status => (
        <option key={status} value={status}>
          {status.replace(/_/g, ' ')}
        </option>
      ))}
    </select>
  );

  const renderOrderCard = (order: Order) => (
    <div key={order.order_number} className="bg-white p-4 rounded-lg shadow space-y-4">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="font-medium">Order #{order.order_number}</h3>
          <p className="text-sm text-gray-500">
            Store: {order.store?.name}
          </p>
          <div className="flex items-center space-x-2">
            <label className="text-sm text-gray-500">Driver:</label>
            <select
              value={order.driver_number || ''}
              onChange={(e) => handleDriverChange(order.order_number, e.target.value)}
              className="text-sm border-gray-300 rounded-md"
            >
              <option value="">Unassigned</option>
              {drivers.map((driver) => (
                <option key={driver.driver_number} value={driver.driver_number}>
                  {driver.name}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          {renderStatusBadge(order)}
          <button
            onClick={() => setDeletingOrder(order.order_number)}
            className="text-red-600 hover:text-red-800"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        </div>
      </div>
      <div className="space-y-2">
        <p className="text-sm">
          <strong>Pickup:</strong> {order.pickup_address}
        </p>
        <p className="text-sm">
          <strong>Delivery:</strong> {order.delivery_address}
        </p>
        {order.description && (
          <p className="text-sm">
            <strong>Description:</strong> {order.description}
          </p>
        )}
        <div className="flex items-center space-x-2">
          <strong className="text-sm">Delivery Price:</strong>
          {editingPrice?.orderNumber === order.order_number ? (
            <div className="flex items-center space-x-2">
              <input
                type="number"
                value={editingPrice.price}
                onChange={(e) => setEditingPrice({ orderNumber: order.order_number, price: e.target.value })}
                onBlur={() => handlePriceChange(order.order_number, editingPrice.price)}
                className="w-24 text-sm border-gray-300 rounded-md"
                step="0.01"
                min="0"
              />
              <span className="text-sm text-gray-500">₪</span>
            </div>
          ) : (
            <button
              onClick={() => setEditingPrice({ orderNumber: order.order_number, price: order.delivery_price.toString() })}
              className="text-sm text-gray-900 hover:text-gray-600"
            >
              ₪{order.delivery_price.toFixed(2)}
            </button>
          )}
        </div>
        <p className="text-sm text-gray-500">
          Created: {formatDateTime(order.created_at)}
        </p>
        {order.updated_at !== order.created_at && (
          <p className="text-sm text-gray-500">
            Last Update: {formatDateTime(order.updated_at)}
          </p>
        )}
      </div>
    </div>
  );

  const renderTable = (orders: Order[]) => (
    <div className="overflow-x-auto bg-white rounded-lg shadow">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Order #
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Status
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Store
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Driver
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Pickup
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Delivery
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Price
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Created
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {orders.map((order) => (
            <tr key={order.order_number} className="hover:bg-gray-50">
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                #{order.order_number}
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                {renderStatusBadge(order)}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {order.store?.name}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm">
                <select
                  value={order.driver_number || ''}
                  onChange={(e) => handleDriverChange(order.order_number, e.target.value)}
                  className="text-sm border-gray-300 rounded-md"
                >
                  <option value="">Unassigned</option>
                  {drivers.map((driver) => (
                    <option key={driver.driver_number} value={driver.driver_number}>
                      {driver.name}
                    </option>
                  ))}
                </select>
              </td>
              <td className="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">
                {order.pickup_address}
              </td>
              <td className="px-6 py-4 text-sm text-gray-500 max-w-xs truncate">
                {order.delivery_address}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm">
                {editingPrice?.orderNumber === order.order_number ? (
                  <div className="flex items-center space-x-2">
                    <input
                      type="number"
                      value={editingPrice.price}
                      onChange={(e) => setEditingPrice({ orderNumber: order.order_number, price: e.target.value })}
                      onBlur={() => handlePriceChange(order.order_number, editingPrice.price)}
                      className="w-24 text-sm border-gray-300 rounded-md"
                      step="0.01"
                      min="0"
                    />
                    <span className="text-sm text-gray-500">₪</span>
                  </div>
                ) : (
                  <button
                    onClick={() => setEditingPrice({ orderNumber: order.order_number, price: order.delivery_price.toString() })}
                    className="text-gray-900 hover:text-gray-600"
                  >
                    ₪{order.delivery_price.toFixed(2)}
                  </button>
                )}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {formatDateTime(order.created_at)}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm">
                <button
                  onClick={() => setDeletingOrder(order.order_number)}
                  className="text-red-600 hover:text-red-800"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  const renderOrderSection = (title: string, orders: Order[]) => (
    <section className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">{title}</h2>
        <span className="px-3 py-1 bg-gray-100 rounded-full text-sm font-medium">
          {orders.length} order{orders.length !== 1 ? 's' : ''}
        </span>
      </div>
      {orders.length > 0 ? (
        viewMode === 'cards' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {orders.map(renderOrderCard)}
          </div>
        ) : (
          renderTable(orders)
        )
      ) : (
        <p className="text-gray-500">No orders in this category</p>
      )}
    </section>
  );

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">All Orders</h1>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 bg-white rounded-lg shadow px-3 py-1">
            <button
              onClick={() => setViewMode('table')}
              className={`p-1 rounded ${viewMode === 'table' ? 'bg-indigo-100 text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
              title="Table view"
            >
              <TableIcon className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode('cards')}
              className={`p-1 rounded ${viewMode === 'cards' ? 'bg-indigo-100 text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
              title="Card view"
            >
              <Grid className="w-5 h-5" />
            </button>
          </div>
          <span className="text-sm font-medium text-gray-500">
            Total Orders: {orders.length}
          </span>
        </div>
      </div>

      {(error || success) && (
        <div className={`p-4 rounded-md ${error ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700'}`}>
          {error || success}
        </div>
      )}

      {renderOrderSection('Active Orders', activeOrders)}
      {renderOrderSection('Completed & Cancelled Orders', inactiveOrders)}

      {/* Delete Confirmation Modal */}
      {deletingOrder && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 max-w-sm w-full">
            <div className="flex items-center space-x-2 text-red-600 mb-4">
              <AlertCircle className="w-6 h-6" />
              <h3 className="text-lg font-medium">Confirm Delete</h3>
            </div>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete order #{deletingOrder}? This action cannot be undone.
            </p>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setDeletingOrder(null)}
                className="px-4 py-2 text-gray-600 hover:text-gray-800"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDeleteOrder(deletingOrder)}
                className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}