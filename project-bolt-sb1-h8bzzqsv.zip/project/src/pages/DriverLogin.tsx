import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { sessionManager } from '../lib/sessionManager';
import { Truck } from 'lucide-react';

export function DriverLogin() {
  const [phone, setPhone] = useState('1234');
  const [driverCode, setDriverCode] = useState('123456');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const checkSession = async () => {
      const session = await sessionManager.getSession();
      if (session?.role === 'driver') {
        navigate('/driver/dashboard');
      }
    };
    checkSession();
  }, [navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // First verify the driver credentials using RPC
      const { data: driverInfo, error: rpcError } = await supabase
        .rpc('verify_driver_credentials', {
          check_phone: phone,
          check_code: driverCode
        });

      if (rpcError || !driverInfo || driverInfo.length === 0) {
        setError('Invalid phone number or driver code');
        return;
      }

      // Create the email for authentication
      const driverEmail = `driver.${phone}@delivery.local`;

      // Try to sign in first
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: driverEmail,
        password: driverCode
      });

      // If sign in fails, create a new account
      if (signInError) {
        const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
          email: driverEmail,
          password: driverCode,
          options: {
            data: {
              role: 'driver'
            }
          }
        });

        if (signUpError) {
          setError('Failed to create account');
          return;
        }

        if (signUpData.user) {
          // Update driver's user_id using RPC
          const { error: updateError } = await supabase
            .rpc('update_driver_user_id', {
              driver_phone: phone,
              new_user_id: signUpData.user.id
            });

          if (updateError) {
            console.error('Error updating driver:', updateError);
            setError('Failed to link driver account');
            return;
          }
        }
      }

      // Clear any existing session cache
      sessionManager.clearCache();
      
      navigate('/driver/dashboard');
    } catch (err) {
      console.error('Login error:', err);
      setError('An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="max-w-md w-full space-y-8 p-8 bg-white rounded-lg shadow-md">
        <div className="flex flex-col items-center">
          <Truck className="w-12 h-12 text-indigo-600" />
          <h2 className="mt-4 text-center text-3xl font-extrabold text-gray-900">
            Driver Login
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Enter your credentials to login
          </p>
        </div>

        {error && (
          <div className="bg-red-50 border-l-4 border-red-400 p-4">
            <div className="flex">
              <div className="ml-3">
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          </div>
        )}

        <form className="mt-8 space-y-6" onSubmit={handleLogin}>
          <div className="space-y-4">
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                Phone Number
              </label>
              <input
                id="phone"
                type="tel"
                required
                className="mt-1 appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                placeholder="Enter your phone number"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
            </div>

            <div>
              <label htmlFor="driverCode" className="block text-sm font-medium text-gray-700">
                Driver Code
              </label>
              <input
                id="driverCode"
                type="text"
                required
                maxLength={6}
                className="mt-1 appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm font-mono uppercase"
                placeholder="Enter your driver code"
                value={driverCode}
                onChange={(e) => setDriverCode(e.target.value.toUpperCase())}
              />
              <p className="mt-1 text-sm text-gray-500">
                Enter the 6-character code provided by your administrator
              </p>
            </div>
          </div>

          <div>
            <button
              type="submit"
              disabled={loading}
              className={`group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white ${
                loading
                  ? 'bg-indigo-400 cursor-not-allowed'
                  : 'bg-indigo-600 hover:bg-indigo-700'
              } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500`}
            >
              {loading ? 'Signing in...' : 'Sign in'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}