-- Drop existing policies
DROP POLICY IF EXISTS "Admin manage drivers" ON drivers;
DROP POLICY IF EXISTS "Admin manage stores" ON drivers;
DROP POLICY IF EXISTS "Admin manage orders" ON orders;

-- Create new admin policies that check username from email
CREATE POLICY "Admin manage drivers"
  ON drivers FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE admin_users.username = SPLIT_PART(auth.jwt() ->> 'email', '@', 1)
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE admin_users.username = SPLIT_PART(auth.jwt() ->> 'email', '@', 1)
    )
  );

CREATE POLICY "Admin manage stores"
  ON stores FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE admin_users.username = SPLIT_PART(auth.jwt() ->> 'email', '@', 1)
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE admin_users.username = SPLIT_PART(auth.jwt() ->> 'email', '@', 1)
    )
  );

CREATE POLICY "Admin manage orders"
  ON orders FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE admin_users.username = SPLIT_PART(auth.jwt() ->> 'email', '@', 1)
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_users 
      WHERE admin_users.username = SPLIT_PART(auth.jwt() ->> 'email', '@', 1)
    )
  );