/*
  # Add blocked status to drivers
  
  1. Changes
    - Add blocked column to drivers table
    - Update policies to restrict blocked status updates to admins only
    - Allow drivers to update only their active status
  
  2. Security
    - Only admins can modify blocked status
    - Drivers cannot modify their own blocked status
    - Public read access maintained
*/

-- Add blocked column to drivers table
ALTER TABLE drivers ADD COLUMN blocked boolean NOT NULL DEFAULT false;

-- Drop existing policies first to avoid conflicts
DROP POLICY IF EXISTS "Admin can manage drivers" ON drivers;
DROP POLICY IF EXISTS "Anyone can view drivers" ON drivers;
DROP POLICY IF EXISTS "Drivers can update their own status" ON drivers;

-- Recreate policies with blocked column handling
CREATE POLICY "Anyone can view drivers"
  ON drivers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admin can manage drivers"
  ON drivers FOR ALL
  TO authenticated
  USING (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  )
  WITH CHECK (
    check_admin_status(SPLIT_PART(auth.jwt() ->> 'email', '@', 1))
  );

-- Create a separate policy for drivers to update only their active status
CREATE POLICY "Drivers can update their active status"
  ON drivers 
  FOR UPDATE
  TO authenticated
  USING (
    driver_user_id = auth.uid()
  )
  WITH CHECK (
    driver_user_id = auth.uid()
    AND (
      -- Only allow updating is_active column
      (TG_OP = 'UPDATE' AND 
       EXISTS (
         SELECT 1 FROM jsonb_each(to_jsonb(NEW)) j
         WHERE j.key NOT IN ('is_active', 'updated_at')
         AND j.value IS DISTINCT FROM jsonb_each(to_jsonb(OLD)).value
       ) IS FALSE)
    )
  );