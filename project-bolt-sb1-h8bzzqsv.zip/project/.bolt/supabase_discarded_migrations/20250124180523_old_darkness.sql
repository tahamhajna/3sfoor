-- Drop existing policies to recreate them with explicit table references
DROP POLICY IF EXISTS "Public read access for drivers" ON drivers;
DROP POLICY IF EXISTS "Admin manage drivers" ON drivers;
DROP POLICY IF EXISTS "Drivers manage themselves" ON drivers;

-- Recreate policies with explicit table references
CREATE POLICY "Public read access for drivers"
  ON drivers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admin manage drivers"
  ON drivers FOR ALL
  TO authenticated
  USING (is_admin(auth.uid()))
  WITH CHECK (is_admin(auth.uid()));

CREATE POLICY "Drivers manage themselves"
  ON drivers FOR UPDATE
  TO authenticated
  USING (drivers.user_id = auth.uid())
  WITH CHECK (drivers.user_id = auth.uid());

-- Update the store policies to be explicit as well
DROP POLICY IF EXISTS "Stores manage themselves" ON stores;

CREATE POLICY "Stores manage themselves"
  ON stores FOR UPDATE
  TO authenticated
  USING (stores.user_id = auth.uid())
  WITH CHECK (stores.user_id = auth.uid());