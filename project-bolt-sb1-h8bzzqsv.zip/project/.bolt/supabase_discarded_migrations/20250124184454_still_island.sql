/*
  # Fix Admin User Management

  1. Changes
    - Drop and recreate admin check function with unique name
    - Update trigger function for new admin users
    - Update policies to use new admin check function

  2. Security
    - Maintain RLS policies
    - Ensure proper admin user creation
*/

-- Drop existing trigger and function if they exist
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS handle_new_user();

-- Drop existing admin check function
DROP FUNCTION IF EXISTS is_admin(uuid);

-- Create a new admin check function with a different name
CREATE OR REPLACE FUNCTION check_admin_status(check_user_id uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM admin_users WHERE admin_users.user_id = check_user_id
  ) OR EXISTS (
    SELECT 1 FROM auth.users 
    WHERE auth.users.id = check_user_id 
    AND auth.users.raw_user_meta_data->>'role' = 'admin'
  );
END;
$$ language plpgsql security definer;

-- Create a more robust function to handle new admin users
CREATE OR REPLACE FUNCTION handle_new_user() 
RETURNS trigger AS $$
BEGIN
  -- Only proceed if the user is marked as an admin
  IF NEW.raw_user_meta_data->>'role' = 'admin' THEN
    -- Insert into admin_users table, ignore if already exists
    INSERT INTO admin_users (user_id)
    VALUES (NEW.id)
    ON CONFLICT (user_id) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$ language plpgsql security definer;

-- Create trigger to handle new users
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- Update admin_users policies
DROP POLICY IF EXISTS "Public read access for admin_users" ON admin_users;

-- Only allow admins to read admin_users table
CREATE POLICY "Admins can read admin_users"
  ON admin_users FOR SELECT
  TO authenticated
  USING (check_admin_status(auth.uid()));

-- Allow the handle_new_user function to insert new admin users
CREATE POLICY "System can insert admin_users"
  ON admin_users FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Update existing policies to use the new admin check function
DROP POLICY IF EXISTS "Admin manage drivers" ON drivers;
CREATE POLICY "Admin manage drivers"
  ON drivers FOR ALL
  TO authenticated
  USING (check_admin_status(auth.uid()))
  WITH CHECK (check_admin_status(auth.uid()));

DROP POLICY IF EXISTS "Admin manage stores" ON stores;
CREATE POLICY "Admin manage stores"
  ON stores FOR ALL
  TO authenticated
  USING (check_admin_status(auth.uid()))
  WITH CHECK (check_admin_status(auth.uid()));

DROP POLICY IF EXISTS "Admin manage orders" ON orders;
CREATE POLICY "Admin manage orders"
  ON orders FOR ALL
  TO authenticated
  USING (check_admin_status(auth.uid()))
  WITH CHECK (check_admin_status(auth.uid()));